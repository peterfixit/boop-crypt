#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "$0")" && pwd)"
DIST="$ROOT/dist-source"
VERSION="$(sed -n 's/^version = "\([^"]*\)"/\1/p' "$ROOT/pyproject.toml" | head -n 1)"

if [[ -z "$VERSION" ]]; then
    echo "Error: could not read the project version from pyproject.toml." >&2
    exit 1
fi

for command in tar zip sha256sum; do
    if ! command -v "$command" >/dev/null 2>&1; then
        echo "Error: '$command' is required to build the source archives." >&2
        exit 1
    fi
done

PACKAGE="boop-crypt-gui-$VERSION-source"
STAGE="$(mktemp -d)"
trap 'rm -rf -- "$STAGE"' EXIT

mkdir -p "$DIST" "$STAGE/$PACKAGE"

source_items=(
    .gitignore
    LICENSE
    README.md
    assets
    build-appimage.sh
    build-source-release.sh
    io.pmhs.BoopCrypt.desktop
    packaging
    pyproject.toml
    run-from-source.sh
    src
    tests
)

for item in "${source_items[@]}"; do
    cp -a "$ROOT/$item" "$STAGE/$PACKAGE/"
done

find "$STAGE/$PACKAGE" -type d \( -name __pycache__ -o -name '*.egg-info' \) -prune -exec rm -rf -- {} +
find "$STAGE/$PACKAGE" -type f \( -name '*.pyc' -o -name '*.pyo' \) -delete

TARBALL="$DIST/$PACKAGE.tar.gz"
ZIPFILE="$DIST/$PACKAGE.zip"
TAR_CHECKSUM="$DIST/$PACKAGE.tar.gz.sha256"
ZIP_CHECKSUM="$DIST/$PACKAGE.zip.sha256"
CHECKSUMS="$DIST/$PACKAGE-SHA256SUMS.txt"

rm -f -- "$TARBALL" "$ZIPFILE" "$TAR_CHECKSUM" "$ZIP_CHECKSUM" "$CHECKSUMS"
tar -C "$STAGE" -czf "$TARBALL" "$PACKAGE"
(
    cd "$STAGE"
    zip -q -r "$ZIPFILE" "$PACKAGE"
)

(
    cd "$DIST"
    sha256sum "$(basename -- "$TARBALL")" >"$(basename -- "$TAR_CHECKSUM")"
    sha256sum "$(basename -- "$ZIPFILE")" >"$(basename -- "$ZIP_CHECKSUM")"
    sha256sum "$(basename -- "$TARBALL")" "$(basename -- "$ZIPFILE")" >"$CHECKSUMS"
)

echo "Source release created:"
echo "  $TARBALL"
echo "  $ZIPFILE"
echo "  $TAR_CHECKSUM"
echo "  $ZIP_CHECKSUM"
echo "  $CHECKSUMS"
