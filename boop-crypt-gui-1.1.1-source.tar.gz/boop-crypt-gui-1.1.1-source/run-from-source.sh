#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "$0")" && pwd)"
VENV="$ROOT/.venv"

cd "$ROOT"

if ! command -v python3 >/dev/null 2>&1; then
    echo "Error: Python 3.11 or newer is required." >&2
    exit 1
fi

if ! python3 - <<'PY'
import sys

if sys.version_info < (3, 11):
    raise SystemExit(f"Python 3.11 or newer is required (found {sys.version.split()[0]}).")

try:
    import tkinter
except ImportError as error:
    raise SystemExit("Python Tk support is required.") from error

if tkinter.TkVersion < 8.6:
    raise SystemExit(f"Tk 8.6 or newer is required (found {tkinter.TkVersion}).")
PY
then
    cat >&2 <<'EOF'

Install the source-build requirements, then run this script again:
  Arch / CachyOS: sudo pacman -S --needed python tk
  Debian / Ubuntu: sudo apt install python3 python3-venv python3-tk
  Fedora / Nobara: sudo dnf install python3 python3-tkinter
EOF
    exit 1
fi

if [[ ! -x "$VENV/bin/python" ]]; then
    echo "Creating local Python environment in .venv ..."
    if ! python3 -m venv "$VENV"; then
        cat >&2 <<'EOF'

Could not create the local Python environment. Install Python's venv support:
  Arch / CachyOS: sudo pacman -S --needed python
  Debian / Ubuntu: sudo apt install python3-venv
  Fedora / Nobara: sudo dnf install python3
EOF
        exit 1
    fi
fi

# shellcheck disable=SC1091
source "$VENV/bin/activate"

echo "Updating the local build tools ..."
python -m pip install --upgrade pip setuptools wheel

echo "Installing Boop Crypt GUI from this source folder ..."
python -m pip install --editable "$ROOT"

missing=()
for dependency in gpg tar xz gzip zstd; do
    if ! command -v "$dependency" >/dev/null 2>&1; then
        missing+=("$dependency")
    fi
done

if ((${#missing[@]})); then
    echo "Warning: missing runtime commands: ${missing[*]}" >&2
    echo "Use Install Dependencies in the GUI, or install them with your package manager." >&2
else
    echo "Runtime dependency check passed: gpg tar xz gzip zstd"
fi

echo "Launching Boop Crypt GUI ..."
exec boop-crypt-gui "$@"
