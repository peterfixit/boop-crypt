#!/usr/bin/env bash
set -Eeuo pipefail

readonly VERSION="1.1.1"
ROOT="$(cd -- "$(dirname -- "$0")" && pwd)"
readonly ROOT
readonly BUILD_ROOT="$ROOT/build-appimage"
readonly APPDIR="$BUILD_ROOT/BoopCrypt.AppDir"
readonly BUILD_DEPS="$ROOT/.build-deps"
readonly OUTPUT_DIR="$ROOT/dist-appimage"

case "$(uname -m)" in
    x86_64)
        readonly APPIMAGE_ARCH="x86_64"
        readonly TOOL_ARCH="x86_64"
        ;;
    aarch64|arm64)
        readonly APPIMAGE_ARCH="aarch64"
        readonly TOOL_ARCH="aarch64"
        ;;
    *)
        printf 'Unsupported architecture: %s\n' "$(uname -m)" >&2
        exit 1
        ;;
esac

readonly OUTPUT="$OUTPUT_DIR/Boop-Crypt-GUI-$VERSION-$APPIMAGE_ARCH.AppImage"
readonly APPIMAGETOOL="$ROOT/tools/appimagetool-$TOOL_ARCH.AppImage"
readonly APPIMAGETOOL_URL="https://github.com/AppImage/AppImageKit/releases/download/continuous/appimagetool-$TOOL_ARCH.AppImage"
PYTHON_LIB_DIR="$(python3 -c 'import _tkinter, pathlib; print(pathlib.Path(_tkinter.__file__).parents[2])')"
readonly PYTHON_LIB_DIR

for command in python3 curl; do
    command -v "$command" >/dev/null 2>&1 || {
        printf 'Missing build command: %s\n' "$command" >&2
        exit 1
    }
done

python3 - <<'PY'
import tkinter
if tkinter.TkVersion < 8.6:
    raise SystemExit("Tk 8.6 or newer is required")
PY

if [[ ! -d "$BUILD_DEPS/PyInstaller" ]]; then
    python3 -m pip install \
        --disable-pip-version-check \
        --target "$BUILD_DEPS" \
        "pyinstaller==6.16.0"
fi

if [[ ! -x "$APPIMAGETOOL" ]]; then
    printf 'Downloading appimagetool for %s...\n' "$TOOL_ARCH"
    curl --fail --location --retry 3 --output "$APPIMAGETOOL" "$APPIMAGETOOL_URL"
    chmod 0755 "$APPIMAGETOOL"
fi

rm -rf -- "$BUILD_ROOT"
mkdir -p -- \
    "$APPDIR/usr/bin" \
    "$APPDIR/usr/share/applications" \
    "$APPDIR/usr/share/icons/hicolor/scalable/apps" \
    "$APPDIR/usr/share/metainfo" \
    "$APPDIR/usr/share/mime/packages" \
    "$OUTPUT_DIR"

PYTHONPATH="$BUILD_DEPS" python3 -m PyInstaller \
    --clean \
    --noconfirm \
    --onedir \
    --windowed \
    --name boop-crypt-gui \
    --paths "$ROOT/src" \
    --add-binary "$PYTHON_LIB_DIR/libtcl9.0.so:." \
    --add-binary "$PYTHON_LIB_DIR/libtcl9tk9.0.so:." \
    --distpath "$BUILD_ROOT/pyinstaller-dist" \
    --workpath "$BUILD_ROOT/pyinstaller-work" \
    --specpath "$BUILD_ROOT" \
    "$ROOT/src/boop_crypt_gui.py"

rm -rf -- "$APPDIR/usr/bin/boop-crypt-gui"
cp -a -- \
    "$BUILD_ROOT/pyinstaller-dist/boop-crypt-gui" \
    "$APPDIR/usr/bin/boop-crypt-gui"
install -m 0755 -- "$ROOT/packaging/AppRun" "$APPDIR/AppRun"
install -m 0644 -- \
    "$ROOT/io.pmhs.BoopCrypt.desktop" \
    "$APPDIR/io.pmhs.BoopCrypt.desktop"
install -m 0644 -- \
    "$ROOT/io.pmhs.BoopCrypt.desktop" \
    "$APPDIR/usr/share/applications/io.pmhs.BoopCrypt.desktop"
install -m 0644 -- \
    "$ROOT/assets/io.pmhs.BoopCrypt.svg" \
    "$APPDIR/io.pmhs.BoopCrypt.svg"
install -m 0644 -- \
    "$ROOT/assets/io.pmhs.BoopCrypt.svg" \
    "$APPDIR/usr/share/icons/hicolor/scalable/apps/io.pmhs.BoopCrypt.svg"
install -m 0644 -- \
    "$ROOT/packaging/io.pmhs.BoopCrypt.appdata.xml" \
    "$APPDIR/usr/share/metainfo/io.pmhs.BoopCrypt.appdata.xml"
install -m 0644 -- \
    "$ROOT/packaging/application-x-boopcrypt.xml" \
    "$APPDIR/usr/share/mime/packages/application-x-boopcrypt.xml"
ln -sfn -- "io.pmhs.BoopCrypt.svg" "$APPDIR/.DirIcon"

rm -f -- "$OUTPUT" "$OUTPUT.sha256"
ARCH="$APPIMAGE_ARCH" \
    "$APPIMAGETOOL" --appimage-extract-and-run "$APPDIR" "$OUTPUT"
chmod 0755 "$OUTPUT"
(
    cd -- "$OUTPUT_DIR"
    sha256sum -- "$(basename -- "$OUTPUT")" > "$(basename -- "$OUTPUT").sha256"
)

printf '\nBuilt:\n  %s\n  %s.sha256\n' "$OUTPUT" "$OUTPUT"
