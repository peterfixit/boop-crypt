from __future__ import annotations

import os
import tempfile
import threading
import unittest
from pathlib import Path

from boopcrypt.core import (
    BoopCryptError,
    OperationOptions,
    append_carrier_record,
    estimate_final_size,
    read_carrier_record,
    strip_carrier,
)
from boopcrypt.engine import BoopCryptEngine
from boopcrypt.gui import MainThreadQueue


class MainThreadQueueTests(unittest.TestCase):
    def test_worker_result_runs_only_when_main_queue_is_drained(self) -> None:
        dispatcher = MainThreadQueue()
        completed: list[str] = []

        worker = threading.Thread(
            target=lambda: dispatcher.submit(completed.append, "ready"),
        )
        worker.start()
        worker.join()

        self.assertEqual(completed, [])
        self.assertEqual(dispatcher.drain(), 1)
        self.assertEqual(completed, ["ready"])


class CarrierFormatTests(unittest.TestCase):
    def test_carrier_footer_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            base = root / "base.bin"
            carrier = root / "carrier.bin"
            stripped = root / "stripped.bin"
            base.write_bytes(b"carrier-base" * 100)
            record = {
                "format_version": 4,
                "key_protection": {
                    "mode": "plain",
                    "key": "x" * 64,
                    "password_protected": False,
                },
                "carrier": {"base_sha256": "0" * 64, "type": "bin"},
                "packages": [],
            }
            append_carrier_record(base, record, carrier)
            found = read_carrier_record(carrier)
            self.assertIsNotNone(found)
            self.assertEqual(found[1]["format_version"], 4)
            extracted = strip_carrier(carrier, stripped)
            self.assertEqual(extracted, record)
            self.assertEqual(stripped.read_bytes(), base.read_bytes())

    def test_estimate_reports_encrypted_size(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            payload = Path(temp) / "compressible.txt"
            payload.write_bytes(b"boop crypt\n" * 100_000)
            estimate = estimate_final_size(payload, "xz")
            self.assertGreater(estimate.source_bytes, 0)
            self.assertLess(estimate.compressed_bytes, estimate.archive_bytes)
            self.assertGreater(estimate.encrypted_bytes, estimate.compressed_bytes)


@unittest.skipUnless(
    all(os.access(path, os.X_OK) for path in ("/usr/bin/gpg", "/usr/bin/tar", "/usr/bin/xz")),
    "GnuPG/TAR/XZ integration tools are unavailable",
)
class EncryptionIntegrationTests(unittest.TestCase):
    def make_engine(self) -> BoopCryptEngine:
        return BoopCryptEngine(
            package_s2k_count=65_536,
            password_s2k_count=65_536,
        )

    def test_password_xz_file_round_trip_and_cli_compatible_pipeline(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            payload = root / "private notes.txt"
            original = (b"secret boop data\n" * 20_000) + os.urandom(4096)
            payload.write_bytes(original)
            engine = self.make_engine()
            encrypted, carrier = engine.encrypt(
                OperationOptions(
                    source=payload,
                    password="correct horse battery staple",
                    cipher="AES256",
                    compression="xz",
                    remove_source=True,
                )
            )
            self.assertFalse(payload.exists())
            self.assertTrue(encrypted.is_file())
            self.assertTrue(carrier.is_file())
            record = read_carrier_record(carrier)[1]
            self.assertEqual(record["format_version"], 4)
            self.assertEqual(record["packages"][0]["pipeline"], "beta2")
            self.assertEqual(record["packages"][0]["cipher"], "AES256")
            self.assertEqual(record["packages"][0]["compression"], "xz")
            self.assertEqual(record["key_protection"]["mode"], "gpg-wrapped")

            with self.assertRaises(BoopCryptError):
                engine.decrypt(
                    OperationOptions(
                        source=encrypted,
                        carrier=carrier,
                        carrier_mode="existing",
                        password="wrong password",
                    )
                )
            self.assertTrue(encrypted.exists())
            restored, _ = engine.decrypt(
                OperationOptions(
                    source=encrypted,
                    carrier=carrier,
                    carrier_mode="existing",
                    password="correct horse battery staple",
                    remove_source=True,
                )
            )
            self.assertEqual(restored.read_bytes(), original)
            self.assertFalse(encrypted.exists())
            updated = read_carrier_record(carrier)[1]
            self.assertEqual(updated["packages"], [])

    def test_gzip_folder_round_trip_uses_gui_pipeline(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            folder = root / "folder"
            folder.mkdir()
            (folder / "one.txt").write_text("one\n" * 20_000, encoding="utf-8")
            nested = folder / "nested"
            nested.mkdir()
            random_data = os.urandom(8192)
            (nested / "two.bin").write_bytes(random_data)
            carrier = root / "my-carrier.bin"
            engine = self.make_engine()
            encrypted, carrier = engine.encrypt(
                OperationOptions(
                    source=folder,
                    carrier=carrier,
                    carrier_mode="create_bin",
                    cipher="AES192",
                    compression="gzip",
                    remove_source=True,
                )
            )
            record = read_carrier_record(carrier)[1]
            self.assertEqual(record["packages"][0]["pipeline"], "gui1")
            self.assertEqual(record["packages"][0]["compression"], "gzip")
            restored, _ = engine.decrypt(
                OperationOptions(
                    source=encrypted,
                    carrier=carrier,
                    carrier_mode="existing",
                    remove_source=True,
                )
            )
            self.assertEqual((restored / "one.txt").read_text(encoding="utf-8"), "one\n" * 20_000)
            self.assertEqual((restored / "nested" / "two.bin").read_bytes(), random_data)


if __name__ == "__main__":
    unittest.main()
