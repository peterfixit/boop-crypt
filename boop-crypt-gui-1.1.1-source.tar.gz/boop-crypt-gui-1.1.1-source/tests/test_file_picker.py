from __future__ import annotations

import subprocess
import unittest
from pathlib import Path

from boopcrypt.file_picker import DesktopFilePicker


class DesktopFilePickerTests(unittest.TestCase):
    def test_kdialog_open_file_uses_title_start_folder_and_filters(self) -> None:
        commands: list[list[str]] = []

        def runner(command: list[str], **_kwargs: object) -> subprocess.CompletedProcess[str]:
            commands.append(command)
            return subprocess.CompletedProcess(command, 0, "/home/peter/file.boopcrypt\n", "")

        picker = DesktopFilePicker(
            object(),
            runner=runner,
            which=lambda command: "/usr/bin/kdialog" if command == "kdialog" else None,
        )
        selected = picker.open_file(
            title="Choose encrypted package",
            initial_dir=Path("/home/peter/Downloads"),
            filetypes=(("Boop Crypt packages", "*.boopcrypt"), ("All files", "*")),
        )

        self.assertEqual(selected, "/home/peter/file.boopcrypt")
        self.assertEqual(commands[0][0], "/usr/bin/kdialog")
        self.assertIn("--getopenfilename", commands[0])
        self.assertIn("/home/peter/Downloads", commands[0])
        self.assertIn("*.boopcrypt|Boop Crypt packages", commands[0][-1])

    def test_native_cancel_does_not_open_another_picker(self) -> None:
        def runner(command: list[str], **_kwargs: object) -> subprocess.CompletedProcess[str]:
            return subprocess.CompletedProcess(command, 1, "", "")

        picker = DesktopFilePicker(
            object(),
            runner=runner,
            which=lambda command: f"/usr/bin/{command}",
        )
        selected = picker.open_directory(
            title="Choose folder to encrypt",
            initial_dir=Path("/home/peter"),
        )
        self.assertEqual(selected, "")

    def test_save_adds_bin_extension_and_decodes_file_url(self) -> None:
        def runner(command: list[str], **_kwargs: object) -> subprocess.CompletedProcess[str]:
            return subprocess.CompletedProcess(
                command,
                0,
                "file:///home/peter/My%20Files/boop-key\n",
                "",
            )

        picker = DesktopFilePicker(
            object(),
            runner=runner,
            which=lambda command: "/usr/bin/zenity" if command == "zenity" else None,
        )
        selected = picker.save_file(
            title="Choose .bin carrier path",
            initial_dir=Path("/home/peter/My Files"),
            initial_file="boop-key.bin",
            default_extension=".bin",
            filetypes=(("Binary carrier", "*.bin"), ("All files", "*")),
        )
        self.assertEqual(selected, "/home/peter/My Files/boop-key.bin")


if __name__ == "__main__":
    unittest.main()
