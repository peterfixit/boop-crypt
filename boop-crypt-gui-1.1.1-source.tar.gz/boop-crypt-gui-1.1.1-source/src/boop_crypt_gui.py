#!/usr/bin/env python3
"""Boop Crypt GUI entry point."""

from __future__ import annotations

import argparse
import os
import tempfile
from pathlib import Path

from boopcrypt import APP_NAME, APP_VERSION


def main() -> None:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} graphical frontend")
    parser.add_argument("--version", action="store_true", help="show the version")
    parser.add_argument(
        "--self-test",
        action="store_true",
        help="test imports without opening the graphical window",
    )
    parser.add_argument(
        "--integration-self-test",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    args = parser.parse_args()
    if args.version:
        print(f"boop-crypt-gui {APP_VERSION}")
        return
    if args.self_test:
        import tkinter

        from boopcrypt.core import check_dependencies
        from boopcrypt.engine import BoopCryptEngine
        from boopcrypt.gui import MainThreadQueue

        assert tkinter.TkVersion >= 8.6
        assert BoopCryptEngine.default_encrypted_path
        dispatcher = MainThreadQueue()
        dispatched: list[str] = []
        dispatcher.submit(dispatched.append, "ready")
        assert dispatcher.drain() == 1 and dispatched == ["ready"]
        found = sum(path is not None for path in check_dependencies().values())
        print(f"boop-crypt-gui {APP_VERSION}: self-test passed ({found}/5 host tools found)")
        return
    if args.integration_self_test:
        from boopcrypt.core import OperationOptions, estimate_final_size
        from boopcrypt.engine import BoopCryptEngine

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            payload = root / "packaged-self-test.txt"
            expected = (b"boop crypt packaged test\n" * 4096) + os.urandom(2048)
            payload.write_bytes(expected)
            estimate = estimate_final_size(payload, "xz")
            if estimate.encrypted_bytes <= 0:
                raise SystemExit("packaged size-estimate self-test failed")
            engine = BoopCryptEngine(
                package_s2k_count=65_536,
                password_s2k_count=65_536,
            )
            encrypted, carrier = engine.encrypt(
                OperationOptions(
                    source=payload,
                    password="packaged-self-test",
                )
            )
            restored, _ = engine.decrypt(
                OperationOptions(
                    source=encrypted,
                    carrier=carrier,
                    carrier_mode="existing",
                    password="packaged-self-test",
                )
            )
            if restored.read_bytes() != expected:
                raise SystemExit("packaged integration self-test failed")
        print(f"boop-crypt-gui {APP_VERSION}: packaged encryption self-test passed")
        return

    from boopcrypt.gui import run_gui

    run_gui()


if __name__ == "__main__":
    main()
