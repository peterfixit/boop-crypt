"""Boop Crypt GUI package."""

from .core import APP_NAME, APP_VERSION

__all__ = ["APP_NAME", "APP_VERSION"]
