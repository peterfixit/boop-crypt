"""Shared constants, carrier format, dependency checks and size estimation."""

from __future__ import annotations

import base64
import datetime as dt
import gzip
import hashlib
import json
import lzma
import os
import posixpath
import secrets
import shutil
import stat
import string
import struct
import subprocess
import tarfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable


APP_NAME = "Boop Crypt"
APP_VERSION = "1.1.1"
PROGRAM_ID = "io.pmhs.BoopCrypt"

MAGIC = b"BOOPCRYPT-KEY-V1"
MAX_RECORD_BYTES = 8 * 1024 * 1024
PACKAGE_S2K_COUNT = 1_048_576
PASSWORD_WRAP_S2K_COUNT = 65_011_712
BIN_CARRIER_SIZE = 128 * 1024

CIPHERS = {
    "AES-256 (recommended)": "AES256",
    "Camellia-256": "CAMELLIA256",
    "Twofish": "TWOFISH",
    "AES-192": "AES192",
    "AES-128": "AES",
}

COMPRESSIONS = {
    "XZ - maximum compression": "xz",
    "Zstandard - balanced": "zstd",
    "Gzip - compatible": "gzip",
}

DEPENDENCY_COMMANDS = ("gpg", "tar", "xz", "gzip", "zstd")


class BoopCryptError(RuntimeError):
    """Expected, user-facing error."""


class DependencyError(BoopCryptError):
    """A required host command is missing."""


@dataclass(slots=True)
class OperationOptions:
    source: Path
    carrier: Path | None = None
    carrier_mode: str = "create_bin"
    cipher: str = "AES256"
    compression: str = "xz"
    password: str = ""
    remove_source: bool = True


@dataclass(slots=True)
class Estimate:
    source_bytes: int
    archive_bytes: int
    compressed_bytes: int
    encrypted_bytes: int
    sampled_bytes: int
    ratio: float


@dataclass(slots=True)
class CarrierState:
    path: Path
    base_path: Path
    carrier_type: str
    base_sha256: str
    vault_id: str
    created_utc: str
    key_mode: str
    key_value: str
    packages: list[dict]
    had_record: bool


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def human_size(size: int | float) -> str:
    value = float(max(size, 0))
    units = ("B", "KiB", "MiB", "GiB", "TiB", "PiB")
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{int(value)} {unit}" if unit == "B" else f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} PiB"


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def compare_files(left: Path, right: Path, chunk_size: int = 1024 * 1024) -> bool:
    if left.stat().st_size != right.stat().st_size:
        return False
    with left.open("rb") as a, right.open("rb") as b:
        while True:
            ac = a.read(chunk_size)
            bc = b.read(chunk_size)
            if ac != bc:
                return False
            if not ac:
                return True


def safe_chmod(path: Path, mode: int = 0o600) -> None:
    try:
        path.chmod(mode)
    except OSError:
        pass


def read_carrier_record(path: Path) -> tuple[int, dict] | None:
    footer_size = 8 + len(MAGIC)
    size = path.stat().st_size
    if size < footer_size:
        return None
    with path.open("rb") as handle:
        handle.seek(-footer_size, os.SEEK_END)
        footer = handle.read(footer_size)
        if footer[8:] != MAGIC:
            return None
        record_length = struct.unpack(">Q", footer[:8])[0]
        if (
            record_length <= 0
            or record_length > MAX_RECORD_BYTES
            or record_length > size - footer_size
        ):
            raise BoopCryptError("The carrier contains an invalid Boop Crypt footer.")
        start = size - footer_size - record_length
        handle.seek(start)
        raw = handle.read(record_length)
    try:
        record = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise BoopCryptError("The carrier's embedded Boop Crypt record is damaged.") from exc
    if not isinstance(record, dict) or record.get("format_version") not in (1, 2, 3, 4):
        raise BoopCryptError("The carrier uses an unsupported Boop Crypt record format.")
    return start, record


def carrier_has_record(path: Path) -> bool:
    return read_carrier_record(path) is not None


def strip_carrier(source: Path, destination: Path) -> dict | None:
    found = read_carrier_record(source)
    length = found[0] if found else source.stat().st_size
    with source.open("rb") as src, destination.open("wb") as dst:
        remaining = length
        while remaining:
            chunk = src.read(min(1024 * 1024, remaining))
            if not chunk:
                raise BoopCryptError("The carrier ended unexpectedly while copying.")
            dst.write(chunk)
            remaining -= len(chunk)
        dst.flush()
        os.fsync(dst.fileno())
    safe_chmod(destination)
    return found[1] if found else None


def append_carrier_record(base: Path, record: dict, destination: Path) -> None:
    if record.get("format_version") != 4:
        raise BoopCryptError("Only Boop Crypt carrier format version 4 can be written.")
    raw = json.dumps(record, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if len(raw) > MAX_RECORD_BYTES:
        raise BoopCryptError("The carrier record is too large.")
    with base.open("rb") as src, destination.open("wb") as dst:
        shutil.copyfileobj(src, dst, 1024 * 1024)
        dst.write(raw)
        dst.write(struct.pack(">Q", len(raw)))
        dst.write(MAGIC)
        dst.flush()
        os.fsync(dst.fileno())
    safe_chmod(destination)


def legacy_package(record: dict) -> dict:
    version = record.get("format_version")
    common = {
        "original_name": record["original_name"],
        "created_utc": record.get("created_utc"),
    }
    if version == 1:
        return {
            **common,
            "pipeline": "alpha1",
            "encrypted_name": record["encrypted_name"],
            "encrypted_sha256": record["encrypted_sha256"],
        }
    if version == 2:
        return {
            **common,
            "pipeline": "beta1",
            "encrypted_name": record["compressed_name"],
            "encrypted_sha256": record["compressed_sha256"],
            "ciphertext_sha256": record["ciphertext_sha256"],
        }
    if version == 3:
        return {
            **common,
            "pipeline": "beta2",
            "encrypted_name": record["encrypted_name"],
            "encrypted_sha256": record["encrypted_sha256"],
            "compressed_archive_sha256": record["compressed_archive_sha256"],
            "archive_sha256": record["archive_sha256"],
            "compression": record.get("compression", "xz"),
        }
    raise BoopCryptError("Unsupported legacy carrier record.")


def normalize_record(record: dict, carrier_type: str) -> dict:
    version = record.get("format_version")
    if version == 4:
        protection = record.get("key_protection")
        carrier = record.get("carrier")
        packages = record.get("packages")
        if not isinstance(protection, dict):
            raise BoopCryptError("The carrier key-protection record is invalid.")
        mode = protection.get("mode")
        if mode == "plain":
            value = protection.get("key")
        elif mode == "gpg-wrapped":
            value = protection.get("wrapped_key_b64")
        else:
            raise BoopCryptError("The carrier uses an unsupported key-protection mode.")
        if not isinstance(value, str) or not value:
            raise BoopCryptError("The carrier key material is missing.")
        if not isinstance(carrier, dict) or not isinstance(carrier.get("base_sha256"), str):
            raise BoopCryptError("The carrier base checksum is missing.")
        if not isinstance(packages, list):
            raise BoopCryptError("The carrier package list is invalid.")
        return {
            "vault_id": record.get("vault_id") or secrets.token_hex(16),
            "created_utc": record.get("created_utc") or utc_now(),
            "base_sha256": carrier["base_sha256"],
            "carrier_type": carrier.get("type") or carrier_type,
            "key_mode": mode,
            "key_value": value,
            "packages": [dict(item) for item in packages if isinstance(item, dict)],
        }
    if version in (1, 2, 3):
        key = record.get("key")
        base_hash = record.get("carrier_sha256")
        if not isinstance(key, str) or not key or not isinstance(base_hash, str):
            raise BoopCryptError("The legacy carrier key metadata is incomplete.")
        return {
            "vault_id": secrets.token_hex(16),
            "created_utc": utc_now(),
            "base_sha256": base_hash,
            "carrier_type": carrier_type,
            "key_mode": "plain",
            "key_value": key,
            "packages": [legacy_package(record)],
        }
    raise BoopCryptError("Unsupported carrier record version.")


def build_record(state: CarrierState, packages: list[dict]) -> dict:
    if state.key_mode == "plain":
        protection = {
            "mode": "plain",
            "key": state.key_value,
            "password_protected": False,
        }
    elif state.key_mode == "gpg-wrapped":
        protection = {
            "mode": "gpg-wrapped",
            "wrapped_key_b64": state.key_value,
            "password_protected": True,
            "wrapper": "gpg-symmetric-aes256",
        }
    else:
        raise BoopCryptError("Invalid internal carrier key mode.")
    return {
        "format_version": 4,
        "program": "boop-crypt",
        "program_version": APP_VERSION,
        "frontend": "boop-crypt-gui",
        "vault_id": state.vault_id,
        "created_utc": state.created_utc,
        "updated_utc": utc_now(),
        "key_protection": protection,
        "carrier": {
            "base_sha256": state.base_sha256,
            "type": state.carrier_type,
        },
        "packages": packages,
    }


def detect_carrier_type(path: Path) -> str:
    with path.open("rb") as handle:
        head = handle.read(16)
    image = (
        head.startswith(b"\xff\xd8\xff")
        or head.startswith(b"\x89PNG\r\n\x1a\n")
        or head.startswith((b"GIF87a", b"GIF89a", b"BM", b"II*\x00", b"MM\x00*"))
        or (head.startswith(b"RIFF") and head[8:12] == b"WEBP")
    )
    if image:
        return "image"
    return "bin" if path.suffix.lower() == ".bin" else "file"


def generate_bin_carrier(path: Path) -> None:
    alphabet = string.ascii_letters + string.digits + string.punctuation + " \n\t"
    random = secrets.SystemRandom()
    with path.open("w", encoding="utf-8", newline="") as handle:
        remaining = BIN_CARRIER_SIZE
        while remaining:
            count = min(8192, remaining)
            handle.write("".join(random.choice(alphabet) for _ in range(count)))
            remaining -= count
        handle.flush()
        os.fsync(handle.fileno())
    safe_chmod(path)


def validate_archive(archive: Path, expected_name: str) -> None:
    try:
        with tarfile.open(archive, "r:") as handle:
            members = handle.getmembers()
            if not members:
                raise BoopCryptError("The archive is empty.")
            for member in members:
                name = member.name
                path = PurePosixPath(name)
                if not name or path.is_absolute() or ".." in path.parts:
                    raise BoopCryptError(f"Unsafe archive path: {name!r}")
                if member.ischr() or member.isblk() or member.isfifo():
                    raise BoopCryptError(f"A special device or FIFO cannot be encrypted: {name!r}")
                if path.parts[0] != expected_name:
                    raise BoopCryptError(f"Unexpected top-level archive entry: {name!r}")
                if member.issym() or member.islnk():
                    link = PurePosixPath(member.linkname)
                    if link.is_absolute():
                        raise BoopCryptError(f"Absolute archive link is not permitted: {name!r}")
                    combined = PurePosixPath(posixpath.normpath(str(path.parent / link)))
                    if not combined.parts or ".." in combined.parts or combined.parts[0] != expected_name:
                        raise BoopCryptError(f"Archive link escapes the payload: {name!r}")
    except (tarfile.TarError, OSError) as exc:
        raise BoopCryptError(f"The TAR archive could not be validated: {exc}") from exc


def required_commands(compression: str | None = None) -> tuple[str, ...]:
    commands = ["gpg", "tar"]
    if compression and compression != "none":
        commands.append(compression)
    return tuple(commands)


def check_dependencies(commands: Iterable[str] = DEPENDENCY_COMMANDS) -> dict[str, str | None]:
    return {command: shutil.which(command) for command in commands}


def ensure_dependencies(commands: Iterable[str]) -> None:
    missing = [command for command in commands if shutil.which(command) is None]
    if missing:
        word = "commands" if len(missing) != 1 else "command"
        raise DependencyError(f"Missing required {word}: {', '.join(missing)}")


def detect_package_manager() -> tuple[str, str]:
    distro = "Linux"
    try:
        values = {}
        for line in Path("/etc/os-release").read_text(encoding="utf-8").splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                values[key] = value.strip().strip('"')
        distro = values.get("PRETTY_NAME") or values.get("NAME") or distro
    except OSError:
        pass
    for manager in ("apt-get", "pacman", "dnf"):
        if shutil.which(manager):
            return manager, distro
    raise DependencyError("No supported package manager was found (apt, pacman or dnf).")


def dependency_install_commands() -> tuple[list[list[str]], str]:
    manager, distro = detect_package_manager()
    if shutil.which("pkexec") is None:
        raise DependencyError(
            "pkexec is required for the Install Dependencies button. "
            "Install polkit or use the command shown under Help."
        )
    if manager == "apt-get":
        return [
            ["pkexec", "apt-get", "update"],
            [
                "pkexec", "apt-get", "install", "-y",
                "gnupg", "tar", "xz-utils", "gzip", "zstd",
            ],
        ], distro
    if manager == "pacman":
        return [[
            "pkexec", "pacman", "-S", "--needed", "--noconfirm",
            "gnupg", "tar", "xz", "gzip", "zstd",
        ]], distro
    return [[
        "pkexec", "dnf", "install", "-y",
        "gnupg2", "tar", "xz", "gzip", "zstd",
    ]], distro


def iter_regular_files(source: Path) -> tuple[list[Path], int, int]:
    if source.is_file():
        return [source], source.stat().st_size, 1
    files = []
    total = 0
    entries = 1
    for root, dirs, names in os.walk(source, followlinks=False):
        entries += len(dirs) + len(names)
        for name in names:
            path = Path(root) / name
            try:
                mode = path.lstat().st_mode
                if stat.S_ISREG(mode):
                    files.append(path)
                    total += path.stat().st_size
            except OSError:
                continue
    return files, total, entries


def sample_files(files: list[Path], limit: int = 8 * 1024 * 1024) -> bytes:
    if not files:
        return b""
    chunks = []
    remaining = limit
    per_file = max(64 * 1024, min(512 * 1024, limit // min(len(files), 32)))
    for path in files:
        if remaining <= 0:
            break
        try:
            size = path.stat().st_size
            take = min(per_file, remaining, size)
            if take <= 0:
                continue
            with path.open("rb") as handle:
                if size <= take:
                    data = handle.read(take)
                else:
                    block = max(1, take // 3)
                    parts = []
                    offsets = (0, max(0, size // 2 - block // 2), max(0, size - block))
                    for offset in offsets:
                        handle.seek(offset)
                        parts.append(handle.read(block))
                    data = b"".join(parts)[:take]
            chunks.append(data)
            remaining -= len(data)
        except OSError:
            continue
    return b"".join(chunks)


def compress_sample(sample: bytes, method: str) -> bytes:
    if method == "none":
        return sample
    if method == "xz":
        return lzma.compress(
            sample,
            format=lzma.FORMAT_XZ,
            preset=6,
            check=lzma.CHECK_SHA256,
        )
    if method == "gzip":
        return gzip.compress(sample, compresslevel=9, mtime=0)
    if method == "zstd":
        ensure_dependencies(("zstd",))
        result = subprocess.run(
            ["zstd", "-10", "-T0", "-q", "--stdout"],
            input=sample,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if result.returncode != 0:
            raise BoopCryptError(result.stderr.decode("utf-8", errors="replace").strip())
        return result.stdout
    raise BoopCryptError(f"Unsupported compression method: {method}")


def estimate_final_size(source: Path, compression: str) -> Estimate:
    source = Path(os.path.abspath(source))
    if not source.exists() and not source.is_symlink():
        raise BoopCryptError("Choose an existing file or folder before estimating its size.")
    files, source_bytes, entries = iter_regular_files(source)
    archive_bytes = source_bytes + entries * 2048 + 10 * 1024
    archive_bytes = ((archive_bytes + 511) // 512) * 512
    sample = sample_files(files)
    if compression == "none" or not sample:
        ratio = 1.0
    else:
        compressed_sample = compress_sample(sample, compression)
        ratio = min(max(len(compressed_sample) / max(len(sample), 1), 0.01), 1.10)
    compressed_bytes = archive_bytes if compression == "none" else int(archive_bytes * ratio) + 4096
    encrypted_bytes = compressed_bytes + 4096
    return Estimate(
        source_bytes=source_bytes,
        archive_bytes=archive_bytes,
        compressed_bytes=compressed_bytes,
        encrypted_bytes=encrypted_bytes,
        sampled_bytes=len(sample),
        ratio=ratio,
    )
