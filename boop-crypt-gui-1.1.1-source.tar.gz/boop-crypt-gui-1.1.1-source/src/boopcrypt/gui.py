"""Tk desktop interface for Boop Crypt."""

from __future__ import annotations

import datetime as dt
import os
import queue
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, scrolledtext, ttk
from typing import Callable

from .core import (
    APP_NAME,
    APP_VERSION,
    CIPHERS,
    COMPRESSIONS,
    DEPENDENCY_COMMANDS,
    BoopCryptError,
    DependencyError,
    OperationOptions,
    check_dependencies,
    dependency_install_commands,
    estimate_final_size,
    human_size,
)
from .engine import BoopCryptEngine
from .file_picker import DesktopFilePicker


COLORS = {
    "bg": "#0f141b",
    "sidebar": "#111923",
    "surface": "#18212d",
    "surface2": "#202b39",
    "surface3": "#263344",
    "text": "#f5f7fa",
    "muted": "#a9b5c5",
    "accent": "#8b5cf6",
    "accent_hover": "#a78bfa",
    "success": "#52d273",
    "warning": "#f5bd4f",
    "danger": "#ff6b6b",
    "border": "#2d3b4d",
    "hero": "#251a4d",
    "hero_border": "#513b83",
}


class MainThreadQueue:
    """Move completed worker results back onto Tk's main thread."""

    def __init__(self) -> None:
        self._queue: queue.Queue[
            tuple[Callable[..., object], tuple[object, ...], dict[str, object]]
        ] = queue.Queue()

    def submit(
        self,
        callback: Callable[..., object],
        *args: object,
        **kwargs: object,
    ) -> None:
        self._queue.put((callback, args, kwargs))

    def drain(self) -> int:
        completed = 0
        while True:
            try:
                callback, args, kwargs = self._queue.get_nowait()
            except queue.Empty:
                return completed
            callback(*args, **kwargs)
            completed += 1


class BoopCryptApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1180x760")
        self.minsize(1000, 680)
        self.configure(bg=COLORS["bg"])
        self.protocol("WM_DELETE_WINDOW", self._close)
        self.bind("<Control-q>", lambda _event: self._close())

        self.log_queue: queue.Queue[tuple[str, str, bool]] = queue.Queue()
        self.ui_queue = MainThreadQueue()
        self.busy = False
        self.worker: threading.Thread | None = None
        self.estimate_generation = 0
        self.file_picker = DesktopFilePicker(self)
        self.last_source_dir = Path.home()
        self.last_carrier_dir: Path | None = None

        self.action_var = tk.StringVar(value="encrypt")
        self.source_var = tk.StringVar()
        self.output_var = tk.StringVar(value="Choose a file or folder")
        self.carrier_mode_var = tk.StringVar(value="create_bin")
        self.carrier_var = tk.StringVar()
        self.carrier_resolved_var = tk.StringVar(
            value="Default: boop-key.bin beside the encrypted package"
        )
        self.cipher_var = tk.StringVar(value=next(iter(CIPHERS)))
        self.compression_enabled_var = tk.BooleanVar(value=True)
        self.compression_var = tk.StringVar(value=next(iter(COMPRESSIONS)))
        self.estimate_var = tk.StringVar(
            value="Estimated compressed size: choose a source"
        )
        self.encrypted_estimate_var = tk.StringVar(
            value="Estimated encrypted package: choose a source"
        )
        self.password_var = tk.StringVar()
        self.show_password_var = tk.BooleanVar(value=False)
        self.remove_source_var = tk.BooleanVar(value=True)
        self.remove_label_var = tk.StringVar(
            value="Remove original only after verified encryption"
        )
        self.verbose_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="Ready")
        self.pages: dict[str, tk.Frame] = {}
        self.nav_buttons: dict[str, tk.Button] = {}
        self.current_page = "operation"
        self.dependency_status_labels: dict[str, tk.Label] = {}

        self._configure_style()
        self._build_menu()
        self._set_icon()
        self._build_shell()
        self._build_pages()
        self._select_action("encrypt")
        self.after(100, self._drain_queues)

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background=COLORS["bg"])
        style.configure(
            "TLabel",
            background=COLORS["bg"],
            foreground=COLORS["text"],
            font=("Sans", 10),
        )
        style.configure(
            "Title.TLabel",
            background=COLORS["bg"],
            foreground=COLORS["text"],
            font=("Sans", 22, "bold"),
        )
        style.configure(
            "Subtitle.TLabel",
            background=COLORS["bg"],
            foreground=COLORS["muted"],
            font=("Sans", 10),
        )
        style.configure(
            "TButton",
            background=COLORS["surface3"],
            foreground=COLORS["text"],
            borderwidth=0,
            padding=(12, 8),
            font=("Sans", 9, "bold"),
        )
        style.map(
            "TButton",
            background=[
                ("active", COLORS["border"]),
                ("disabled", COLORS["surface"]),
            ],
            foreground=[("disabled", "#667384")],
        )
        style.configure(
            "Accent.TButton",
            background=COLORS["accent"],
            foreground="#140b28",
            padding=(16, 10),
            font=("Sans", 10, "bold"),
        )
        style.map(
            "Accent.TButton",
            background=[
                ("active", COLORS["accent_hover"]),
                ("disabled", COLORS["surface2"]),
            ],
            foreground=[("disabled", "#667384")],
        )
        style.configure(
            "Danger.TButton",
            background=COLORS["danger"],
            foreground="#250505",
        )
        style.map("Danger.TButton", background=[("active", "#ff8a8a")])
        style.configure(
            "TEntry",
            fieldbackground=COLORS["surface2"],
            foreground=COLORS["text"],
            insertcolor=COLORS["text"],
            bordercolor=COLORS["border"],
            lightcolor=COLORS["border"],
            darkcolor=COLORS["border"],
            padding=8,
        )
        style.configure(
            "TCombobox",
            fieldbackground=COLORS["surface2"],
            background=COLORS["surface2"],
            foreground=COLORS["text"],
            arrowcolor=COLORS["muted"],
            bordercolor=COLORS["border"],
            lightcolor=COLORS["border"],
            darkcolor=COLORS["border"],
            padding=7,
        )
        style.map(
            "TCombobox",
            fieldbackground=[
                ("readonly", COLORS["surface2"]),
                ("disabled", COLORS["surface"]),
            ],
            foreground=[
                ("readonly", COLORS["text"]),
                ("disabled", "#667384"),
            ],
        )
        for widget in ("TCheckbutton", "TRadiobutton"):
            style.configure(
                f"Card.{widget}",
                background=COLORS["surface"],
                foreground=COLORS["text"],
                font=("Sans", 9),
            )
            style.map(
                f"Card.{widget}",
                background=[("active", COLORS["surface"])],
                foreground=[("disabled", "#667384")],
            )
        style.configure(
            "Horizontal.TProgressbar",
            troughcolor=COLORS["surface2"],
            background=COLORS["accent"],
            borderwidth=0,
        )

    def _set_icon(self) -> None:
        candidates = [
            os.environ.get("BOOP_CRYPT_ICON", ""),
            os.fspath(
                Path(__file__).resolve().parents[2]
                / "assets"
                / "io.pmhs.BoopCrypt.svg"
            ),
        ]
        for icon in candidates:
            if not icon or not Path(icon).is_file():
                continue
            try:
                self._icon_image = tk.PhotoImage(file=icon)
                self.iconphoto(True, self._icon_image)
                return
            except tk.TclError:
                continue

    def _build_menu(self) -> None:
        menu = tk.Menu(self)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(
            label="Encrypt",
            command=lambda: self._select_action("encrypt"),
        )
        file_menu.add_command(
            label="Decrypt",
            command=lambda: self._select_action("decrypt"),
        )
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self._close)
        menu.add_cascade(label="File", menu=file_menu)

        tools_menu = tk.Menu(menu, tearoff=False)
        tools_menu.add_command(
            label="Test Dependencies",
            command=self._test_dependencies,
        )
        tools_menu.add_command(
            label="Install Dependencies",
            command=self._install_dependencies,
        )
        tools_menu.add_separator()
        tools_menu.add_command(label="Estimate Size", command=self._start_estimate)
        tools_menu.add_command(label="Clear Console", command=self._clear_console)
        menu.add_cascade(label="Tools", menu=tools_menu)

        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label="How to Encrypt", command=self._how_to_encrypt)
        help_menu.add_command(label="How to Decrypt", command=self._how_to_decrypt)
        help_menu.add_command(label="Carrier and Passwords", command=self._carrier_help)
        help_menu.add_command(label="Dependency Commands", command=self._dependency_help)
        help_menu.add_separator()
        help_menu.add_command(label="About Boop Crypt", command=self._about)
        menu.add_cascade(label="Help", menu=help_menu)
        self.configure(menu=menu)

    def _build_shell(self) -> None:
        sidebar = tk.Frame(self, bg=COLORS["sidebar"], width=220)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        brand = tk.Frame(sidebar, bg=COLORS["sidebar"])
        brand.pack(fill="x", padx=20, pady=(24, 26))
        tk.Label(
            brand,
            text="B",
            bg=COLORS["accent"],
            fg="#140b28",
            font=("Sans", 18, "bold"),
            width=2,
            height=1,
        ).pack(side="left")
        brand_text = tk.Frame(brand, bg=COLORS["sidebar"])
        brand_text.pack(side="left", padx=12)
        tk.Label(
            brand_text,
            text=APP_NAME,
            bg=COLORS["sidebar"],
            fg=COLORS["text"],
            font=("Sans", 16, "bold"),
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            brand_text,
            text=f"Secure files  •  {APP_VERSION}",
            bg=COLORS["sidebar"],
            fg=COLORS["muted"],
            font=("Sans", 8),
            anchor="w",
        ).pack(fill="x")

        nav_items = [
            ("encrypt", "🔒", "Encrypt", lambda: self._select_action("encrypt")),
            ("decrypt", "🔓", "Decrypt", lambda: self._select_action("decrypt")),
            ("dependencies", "✓", "Dependencies", lambda: self._show_page("dependencies")),
            ("activity", ">_", "Activity", lambda: self._show_page("activity")),
        ]
        for key, glyph, label, command in nav_items:
            button = tk.Button(
                sidebar,
                text=f"  {glyph}    {label}",
                anchor="w",
                bg=COLORS["sidebar"],
                fg=COLORS["muted"],
                activebackground=COLORS["surface2"],
                activeforeground=COLORS["text"],
                relief="flat",
                bd=0,
                padx=18,
                pady=12,
                font=("Sans", 10, "bold"),
                command=command,
                cursor="hand2",
            )
            button.pack(fill="x", padx=10, pady=2)
            self.nav_buttons[key] = button

        help_box = tk.Frame(sidebar, bg=COLORS["sidebar"])
        help_box.pack(side="bottom", fill="x", padx=18, pady=(0, 18))
        tk.Button(
            help_box,
            text="How it works",
            anchor="w",
            bg=COLORS["sidebar"],
            fg=COLORS["muted"],
            activebackground=COLORS["surface2"],
            activeforeground=COLORS["text"],
            relief="flat",
            bd=0,
            font=("Sans", 9),
            command=self._carrier_help,
            cursor="hand2",
        ).pack(fill="x", pady=(0, 12))
        footer = tk.Frame(help_box, bg=COLORS["sidebar"])
        footer.pack(fill="x")
        self.side_status_dot = tk.Label(
            footer,
            text="●",
            fg=COLORS["success"],
            bg=COLORS["sidebar"],
            font=("Sans", 10),
        )
        self.side_status_dot.pack(side="left")
        self.side_status = tk.Label(
            footer,
            textvariable=self.status_var,
            fg=COLORS["muted"],
            bg=COLORS["sidebar"],
            font=("Sans", 8),
            anchor="w",
        )
        self.side_status.pack(side="left", padx=6)

        main = tk.Frame(self, bg=COLORS["bg"])
        main.pack(side="left", fill="both", expand=True)
        header = tk.Frame(main, bg=COLORS["bg"])
        header.pack(fill="x", padx=30, pady=(20, 12))
        heading = tk.Frame(header, bg=COLORS["bg"])
        heading.pack(side="left", fill="x", expand=True)
        self.page_title = ttk.Label(heading, text="Encrypt", style="Title.TLabel")
        self.page_title.pack(anchor="w")
        self.page_subtitle = ttk.Label(
            heading,
            text="Protect a file or folder with a separate reusable carrier",
            style="Subtitle.TLabel",
        )
        self.page_subtitle.pack(anchor="w", pady=(2, 0))
        self.progress = ttk.Progressbar(header, mode="indeterminate", length=92)
        self.progress.pack(side="right", padx=(12, 0))
        ttk.Button(
            header,
            text="Exit",
            style="Danger.TButton",
            command=self._close,
        ).pack(side="right")

        self.page_host = tk.Frame(main, bg=COLORS["bg"])
        self.page_host.pack(fill="both", expand=True, padx=30, pady=(0, 26))

    def _page(self, key: str) -> tk.Frame:
        page = tk.Frame(self.page_host, bg=COLORS["bg"])
        self.pages[key] = page
        return page

    def _card(
        self,
        parent: tk.Widget,
        title: str,
        subtitle: str = "",
    ) -> tuple[tk.Frame, tk.Frame]:
        card = tk.Frame(
            parent,
            bg=COLORS["surface"],
            highlightbackground=COLORS["border"],
            highlightthickness=1,
            padx=17,
            pady=15,
        )
        tk.Label(
            card,
            text=title,
            bg=COLORS["surface"],
            fg=COLORS["text"],
            font=("Sans", 12, "bold"),
            anchor="w",
        ).pack(fill="x")
        if subtitle:
            tk.Label(
                card,
                text=subtitle,
                bg=COLORS["surface"],
                fg=COLORS["muted"],
                font=("Sans", 9),
                anchor="w",
                justify="left",
                wraplength=390,
            ).pack(fill="x", pady=(3, 12))
        body = tk.Frame(card, bg=COLORS["surface"])
        body.pack(fill="both", expand=True)
        return card, body

    def _build_pages(self) -> None:
        self._build_operation_page()
        self._build_dependencies_page()
        self._build_activity_page()
        self._queue_log(
            "INFO",
            "Ready. Choose Encrypt or Decrypt, then select the source and carrier.",
            False,
        )
        self._queue_log(
            "INFO",
            f"File chooser: {self.file_picker.backend_name}.",
            False,
        )

    def _build_operation_page(self) -> None:
        page = self._page("operation")
        page.columnconfigure(0, weight=1)
        page.rowconfigure(1, weight=1)

        hero = tk.Frame(
            page,
            bg=COLORS["hero"],
            highlightbackground=COLORS["hero_border"],
            highlightthickness=1,
        )
        hero.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        hero.columnconfigure(0, weight=1)
        hero_text = tk.Frame(hero, bg=COLORS["hero"])
        hero_text.grid(row=0, column=0, sticky="ew", padx=22, pady=16)
        self.hero_title = tk.Label(
            hero_text,
            text="Protect what matters",
            bg=COLORS["hero"],
            fg=COLORS["text"],
            font=("Sans", 18, "bold"),
            anchor="w",
        )
        self.hero_title.pack(fill="x")
        self.hero_subtitle = tk.Label(
            hero_text,
            text="Encrypt a file or folder, verify it end to end, then keep its carrier somewhere safe.",
            bg=COLORS["hero"],
            fg="#d8cef7",
            font=("Sans", 9),
            anchor="w",
            justify="left",
        )
        self.hero_subtitle.pack(fill="x", pady=(3, 0))
        self.mode_badge = tk.Label(
            hero,
            text="ENCRYPT MODE",
            bg=COLORS["accent"],
            fg="#140b28",
            font=("Sans", 8, "bold"),
            padx=12,
            pady=6,
        )
        self.mode_badge.grid(row=0, column=1, padx=22)

        workspace = tk.Frame(page, bg=COLORS["bg"])
        workspace.grid(row=1, column=0, sticky="nsew")
        workspace.columnconfigure(0, weight=1, uniform="operation")
        workspace.columnconfigure(1, weight=1, uniform="operation")
        workspace.rowconfigure(0, weight=1)
        workspace.rowconfigure(1, weight=1)

        source_card, source = self._card(
            workspace,
            "1  Choose the source",
            "Select the file or folder you want Boop Crypt to process.",
        )
        source_card.grid(row=0, column=0, sticky="nsew", padx=(0, 7), pady=(0, 7))
        self.source_caption = tk.Label(
            source,
            text="FILE OR FOLDER",
            bg=COLORS["surface"],
            fg=COLORS["muted"],
            font=("Sans", 8, "bold"),
            anchor="w",
        )
        self.source_caption.pack(fill="x", pady=(0, 5))
        source_row = tk.Frame(source, bg=COLORS["surface"])
        source_row.pack(fill="x")
        self.source_entry = ttk.Entry(source_row, textvariable=self.source_var)
        self.source_entry.pack(side="left", fill="x", expand=True)
        self.source_entry.bind("<FocusOut>", lambda _event: self._source_changed())
        ttk.Button(source_row, text="File", command=self._choose_file).pack(
            side="left", padx=(7, 0)
        )
        self.folder_button = ttk.Button(
            source_row,
            text="Folder",
            command=self._choose_folder,
        )
        self.folder_button.pack(side="left", padx=(7, 0))
        tk.Label(
            source,
            text="OUTPUT",
            bg=COLORS["surface"],
            fg=COLORS["muted"],
            font=("Sans", 8, "bold"),
            anchor="w",
        ).pack(fill="x", pady=(12, 3))
        self.output_label = tk.Label(
            source,
            textvariable=self.output_var,
            bg=COLORS["surface"],
            fg=COLORS["text"],
            font=("Sans", 9),
            anchor="w",
            justify="left",
            wraplength=390,
        )
        self.output_label.pack(fill="x")

        carrier_card, carrier = self._card(
            workspace,
            "2  Choose the carrier",
            "The carrier stores the separate key. Keep it away from the encrypted package.",
        )
        carrier_card.grid(row=0, column=1, sticky="nsew", padx=(7, 0), pady=(0, 7))
        carrier_modes = tk.Frame(carrier, bg=COLORS["surface"])
        carrier_modes.pack(fill="x", pady=(0, 8))
        self.bin_radio = ttk.Radiobutton(
            carrier_modes,
            text="Create .bin",
            value="create_bin",
            variable=self.carrier_mode_var,
            command=self._carrier_mode_changed,
            style="Card.TRadiobutton",
        )
        self.bin_radio.pack(side="left")
        self.existing_radio = ttk.Radiobutton(
            carrier_modes,
            text="Use existing file or image",
            value="existing",
            variable=self.carrier_mode_var,
            command=self._carrier_mode_changed,
            style="Card.TRadiobutton",
        )
        self.existing_radio.pack(side="left", padx=(16, 0))
        carrier_row = tk.Frame(carrier, bg=COLORS["surface"])
        carrier_row.pack(fill="x")
        self.carrier_entry = ttk.Entry(carrier_row, textvariable=self.carrier_var)
        self.carrier_entry.pack(side="left", fill="x", expand=True)
        self.carrier_entry.bind("<FocusOut>", lambda _event: self._update_paths())
        ttk.Button(carrier_row, text="Browse", command=self._choose_carrier).pack(
            side="left", padx=(7, 0)
        )
        ttk.Button(
            carrier_row,
            text="Clear",
            command=lambda: (self.carrier_var.set(""), self._update_paths()),
        ).pack(side="left", padx=(7, 0))
        self.carrier_hint = tk.Label(
            carrier,
            textvariable=self.carrier_resolved_var,
            bg=COLORS["surface"],
            fg=COLORS["muted"],
            font=("Sans", 8),
            anchor="w",
            justify="left",
            wraplength=390,
        )
        self.carrier_hint.pack(fill="x", pady=(9, 0))

        crypto_card, crypto = self._card(
            workspace,
            "3  Encryption and compression",
            "AES-256 with XZ is the recommended compatible default.",
        )
        crypto_card.grid(row=1, column=0, sticky="nsew", padx=(0, 7), pady=(7, 0))
        crypto_row = tk.Frame(crypto, bg=COLORS["surface"])
        crypto_row.pack(fill="x")
        crypto_row.columnconfigure(0, weight=1)
        crypto_row.columnconfigure(1, weight=1)
        cipher_box = tk.Frame(crypto_row, bg=COLORS["surface"])
        cipher_box.grid(row=0, column=0, sticky="ew", padx=(0, 7))
        tk.Label(
            cipher_box,
            text="ENCRYPTION METHOD",
            bg=COLORS["surface"],
            fg=COLORS["muted"],
            font=("Sans", 8, "bold"),
            anchor="w",
        ).pack(fill="x", pady=(0, 4))
        self.cipher_combo = ttk.Combobox(
            cipher_box,
            textvariable=self.cipher_var,
            values=list(CIPHERS),
            state="readonly",
        )
        self.cipher_combo.pack(fill="x")
        compression_box = tk.Frame(crypto_row, bg=COLORS["surface"])
        compression_box.grid(row=0, column=1, sticky="ew", padx=(7, 0))
        self.compression_check = ttk.Checkbutton(
            compression_box,
            text="Use compression",
            variable=self.compression_enabled_var,
            command=self._compression_changed,
            style="Card.TCheckbutton",
        )
        self.compression_check.pack(anchor="w", pady=(0, 3))
        self.compression_combo = ttk.Combobox(
            compression_box,
            textvariable=self.compression_var,
            values=list(COMPRESSIONS),
            state="readonly",
        )
        self.compression_combo.pack(fill="x")
        self.compression_combo.bind(
            "<<ComboboxSelected>>",
            lambda _event: self._start_estimate(),
        )
        estimate_panel = tk.Frame(crypto, bg=COLORS["surface2"], padx=10, pady=8)
        estimate_panel.pack(fill="x", pady=(10, 0))
        self.estimate_label = tk.Label(
            estimate_panel,
            textvariable=self.estimate_var,
            bg=COLORS["surface2"],
            fg=COLORS["muted"],
            font=("Sans", 8),
            anchor="w",
        )
        self.estimate_label.pack(fill="x")
        self.encrypted_estimate_label = tk.Label(
            estimate_panel,
            textvariable=self.encrypted_estimate_var,
            bg=COLORS["surface2"],
            fg=COLORS["text"],
            font=("Sans", 8, "bold"),
            anchor="w",
        )
        self.encrypted_estimate_label.pack(fill="x", pady=(2, 0))

        security_card, security = self._card(
            workspace,
            "4  Password and safety",
            "A password is optional and protects the key stored inside the carrier.",
        )
        security_card.grid(row=1, column=1, sticky="nsew", padx=(7, 0), pady=(7, 0))
        password_row = tk.Frame(security, bg=COLORS["surface"])
        password_row.pack(fill="x")
        self.password_entry = ttk.Entry(
            password_row,
            textvariable=self.password_var,
            show="*",
        )
        self.password_entry.pack(side="left", fill="x", expand=True)
        ttk.Checkbutton(
            password_row,
            text="Show",
            variable=self.show_password_var,
            command=self._toggle_password,
            style="Card.TCheckbutton",
        ).pack(side="left", padx=(10, 0))
        ttk.Checkbutton(
            security,
            textvariable=self.remove_label_var,
            variable=self.remove_source_var,
            style="Card.TCheckbutton",
        ).pack(anchor="w", pady=(12, 0))
        safety = tk.Frame(security, bg=COLORS["surface2"], padx=10, pady=8)
        safety.pack(fill="x", pady=(10, 0))
        tk.Label(
            safety,
            text="✓  Removal happens only after a complete verification pass.",
            bg=COLORS["surface2"],
            fg=COLORS["success"],
            font=("Sans", 8, "bold"),
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            safety,
            text="The password is never written to the activity log.",
            bg=COLORS["surface2"],
            fg=COLORS["muted"],
            font=("Sans", 8),
            anchor="w",
        ).pack(fill="x", pady=(2, 0))

        actions = tk.Frame(page, bg=COLORS["surface"], padx=14, pady=10)
        actions.grid(row=2, column=0, sticky="ew", pady=(14, 0))
        tk.Label(
            actions,
            textvariable=self.status_var,
            bg=COLORS["surface"],
            fg=COLORS["muted"],
            font=("Sans", 9, "bold"),
        ).pack(side="left")
        ttk.Button(
            actions,
            text="View activity",
            command=lambda: self._show_page("activity"),
        ).pack(side="left", padx=(12, 0))
        self.start_button = ttk.Button(
            actions,
            text="Encrypt",
            style="Accent.TButton",
            command=self._start_operation,
        )
        self.start_button.pack(side="right")
        self.estimate_button = ttk.Button(
            actions,
            text="Estimate size",
            command=self._start_estimate,
        )
        self.estimate_button.pack(side="right", padx=(0, 8))

    def _build_dependencies_page(self) -> None:
        page = self._page("dependencies")
        intro = tk.Frame(
            page,
            bg="#173251",
            highlightbackground="#285d8d",
            highlightthickness=1,
        )
        intro.pack(fill="x", pady=(0, 16))
        tk.Label(
            intro,
            text="Everything Boop Crypt needs",
            bg="#173251",
            fg=COLORS["text"],
            font=("Sans", 18, "bold"),
            anchor="w",
        ).pack(fill="x", padx=22, pady=(17, 3))
        tk.Label(
            intro,
            text="Test the five host tools or install the missing packages with graphical administrator authentication.",
            bg="#173251",
            fg="#c3d9ef",
            font=("Sans", 9),
            anchor="w",
        ).pack(fill="x", padx=22, pady=(0, 17))

        card, body = self._card(
            page,
            "Dependency status",
            "The AppImage includes the GUI and Python runtime. These command-line tools come from your Linux system.",
        )
        card.pack(fill="both", expand=True)
        status_grid = tk.Frame(body, bg=COLORS["surface"])
        status_grid.pack(fill="x")
        for index, command in enumerate(DEPENDENCY_COMMANDS):
            row = index // 2
            column = index % 2
            item = tk.Frame(
                status_grid,
                bg=COLORS["surface2"],
                padx=12,
                pady=10,
            )
            item.grid(
                row=row,
                column=column,
                sticky="ew",
                padx=(0, 6) if column == 0 else (6, 0),
                pady=6,
            )
            status_grid.columnconfigure(column, weight=1, uniform="dependencies")
            tk.Label(
                item,
                text=command,
                bg=COLORS["surface2"],
                fg=COLORS["text"],
                font=("Monospace", 10, "bold"),
            ).pack(side="left")
            label = tk.Label(
                item,
                text="Not tested",
                bg=COLORS["surface2"],
                fg=COLORS["muted"],
                font=("Sans", 9),
            )
            label.pack(side="right")
            self.dependency_status_labels[command] = label
        self.dependency_summary = tk.Label(
            body,
            text="Select Test dependencies to check this computer.",
            bg=COLORS["surface"],
            fg=COLORS["muted"],
            font=("Sans", 9),
            anchor="w",
        )
        self.dependency_summary.pack(fill="x", pady=(12, 8))
        dependency_actions = tk.Frame(body, bg=COLORS["surface"])
        dependency_actions.pack(fill="x")
        self.test_button = ttk.Button(
            dependency_actions,
            text="Test dependencies",
            command=self._test_dependencies,
        )
        self.test_button.pack(side="left")
        self.install_button = ttk.Button(
            dependency_actions,
            text="Install missing dependencies",
            style="Accent.TButton",
            command=self._install_dependencies,
        )
        self.install_button.pack(side="left", padx=(8, 0))
        ttk.Button(
            dependency_actions,
            text="Manual commands",
            command=self._dependency_help,
        ).pack(side="right")

    def _build_activity_page(self) -> None:
        page = self._page("activity")
        card, body = self._card(
            page,
            "Activity log",
            "Encryption, verification, dependency checks and errors appear here in real time.",
        )
        card.pack(fill="both", expand=True)
        console_box = tk.Frame(body, bg="#0b1016")
        console_box.pack(fill="both", expand=True)
        self.console = scrolledtext.ScrolledText(
            console_box,
            wrap=tk.WORD,
            state=tk.DISABLED,
            font=("Monospace", 9),
            background="#0b1016",
            foreground="#d8e3ef",
            insertbackground=COLORS["text"],
            relief=tk.FLAT,
            borderwidth=0,
            padx=13,
            pady=12,
        )
        self.console.pack(fill="both", expand=True)
        self.console.tag_configure("INFO", foreground="#bfdbfe")
        self.console.tag_configure("SUCCESS", foreground="#86efac")
        self.console.tag_configure("WARN", foreground="#fde68a")
        self.console.tag_configure("ERROR", foreground="#fca5a5")
        self.console.tag_configure("VERBOSE", foreground="#c4b5fd")
        controls = tk.Frame(body, bg=COLORS["surface"])
        controls.pack(fill="x", pady=(10, 0))
        ttk.Checkbutton(
            controls,
            text="Verbose output",
            variable=self.verbose_var,
            style="Card.TCheckbutton",
        ).pack(side="left")
        tk.Label(
            controls,
            textvariable=self.status_var,
            bg=COLORS["surface"],
            fg=COLORS["muted"],
            font=("Sans", 9, "bold"),
        ).pack(side="right", padx=(12, 0))
        ttk.Button(
            controls,
            text="Clear activity",
            command=self._clear_console,
        ).pack(side="right")

    def _show_page(self, key: str) -> None:
        if key not in self.pages:
            return
        for page in self.pages.values():
            page.pack_forget()
        self.pages[key].pack(fill="both", expand=True)
        self.current_page = key
        if key == "operation":
            active = self.action_var.get()
            if active == "encrypt":
                title = "Encrypt"
                subtitle = "Protect a file or folder with a separate reusable carrier"
            else:
                title = "Decrypt"
                subtitle = "Restore and verify a .boopcrypt package"
        elif key == "dependencies":
            active = "dependencies"
            title = "Dependencies"
            subtitle = "Check or install the host tools used by Boop Crypt"
        else:
            active = "activity"
            title = "Activity"
            subtitle = "Live operation and diagnostic output"
        self.page_title.configure(text=title)
        self.page_subtitle.configure(text=subtitle)
        for nav_key, button in self.nav_buttons.items():
            selected = nav_key == active
            button.configure(
                bg=COLORS["surface2"] if selected else COLORS["sidebar"],
                fg=COLORS["text"] if selected else COLORS["muted"],
            )

    def _select_action(self, action: str) -> None:
        if self.busy:
            return
        self.action_var.set(action)
        self._update_mode()
        self._show_page("operation")

    def _update_mode(self) -> None:
        encrypting = self.action_var.get() == "encrypt"
        self.start_button.configure(text="Encrypt" if encrypting else "Decrypt")
        self.estimate_button.configure(state=tk.NORMAL if encrypting else tk.DISABLED)
        self.folder_button.configure(
            state=tk.NORMAL if encrypting else tk.DISABLED
        )
        crypto_state = "readonly" if encrypting else tk.DISABLED
        self.cipher_combo.configure(state=crypto_state)
        self.compression_check.configure(
            state=tk.NORMAL if encrypting else tk.DISABLED
        )
        self.compression_combo.configure(
            state=(
                "readonly"
                if encrypting and self.compression_enabled_var.get()
                else tk.DISABLED
            )
        )
        self.bin_radio.configure(
            state=tk.NORMAL if encrypting else tk.DISABLED
        )
        if not encrypting:
            self.carrier_mode_var.set("existing")
            self.hero_title.configure(text="Bring it back safely")
            self.hero_subtitle.configure(
                text="Match the encrypted package with its carrier, then restore and verify the original payload."
            )
            self.mode_badge.configure(text="DECRYPT MODE")
            self.source_caption.configure(text="ENCRYPTED PACKAGE")
            self.estimate_var.set("Encryption method: read from the carrier")
            self.encrypted_estimate_var.set(
                "Compression and original file details are detected automatically"
            )
        else:
            self.hero_title.configure(text="Protect what matters")
            self.hero_subtitle.configure(
                text="Encrypt a file or folder, verify it end to end, then keep its carrier somewhere safe."
            )
            self.mode_badge.configure(text="ENCRYPT MODE")
            self.source_caption.configure(text="FILE OR FOLDER")
            if not self.source_var.get().strip():
                self.estimate_var.set("Estimated compressed size: choose a source")
                self.encrypted_estimate_var.set(
                    "Estimated encrypted package: choose a source"
                )
        self.remove_label_var.set(
            "Remove original only after verified encryption"
            if encrypting
            else "Remove encrypted package after verified restoration"
        )
        self._update_paths()

    def _carrier_mode_changed(self) -> None:
        self._update_paths()

    def _compression_changed(self) -> None:
        self.compression_combo.configure(
            state=(
                "readonly"
                if self.compression_enabled_var.get()
                and self.action_var.get() == "encrypt"
                else tk.DISABLED
            )
        )
        self._start_estimate()

    def _toggle_password(self) -> None:
        self.password_entry.configure(
            show="" if self.show_password_var.get() else "*"
        )

    def _choose_file(self) -> None:
        filetypes = (
            [("Boop Crypt packages", "*.boopcrypt"), ("All files", "*")]
            if self.action_var.get() == "decrypt"
            else [("All files", "*")]
        )
        selected = self.file_picker.open_file(
            title=(
                "Choose encrypted package"
                if self.action_var.get() == "decrypt"
                else "Choose file to encrypt"
            ),
            filetypes=filetypes,
            initial_dir=self._selection_directory(
                self.source_var.get(),
                self.last_source_dir,
            ),
        )
        if selected:
            self.source_var.set(selected)
            self.last_source_dir = Path(selected).expanduser().parent
            self._source_changed()

    def _choose_folder(self) -> None:
        selected = self.file_picker.open_directory(
            title="Choose folder to encrypt",
            initial_dir=self._selection_directory(
                self.source_var.get(),
                self.last_source_dir,
            ),
        )
        if selected:
            self.source_var.set(selected)
            self.last_source_dir = Path(selected).expanduser()
            self._source_changed()

    def _choose_carrier(self) -> None:
        if (
            self.action_var.get() == "encrypt"
            and self.carrier_mode_var.get() == "create_bin"
        ):
            source_dir = self._source_parent_directory()
            initial_dir = self._selection_directory(
                self.carrier_var.get(),
                self.last_carrier_dir or source_dir,
            )
            selected = self.file_picker.save_file(
                title="Choose .bin carrier path",
                initial_dir=initial_dir,
                initial_file="boop-key.bin",
                default_extension=".bin",
                filetypes=[("Binary carrier", "*.bin"), ("All files", "*")],
            )
        else:
            source_dir = self._source_parent_directory()
            selected = self.file_picker.open_file(
                title="Choose existing carrier or image",
                initial_dir=self._selection_directory(
                    self.carrier_var.get(),
                    self.last_carrier_dir or source_dir,
                ),
                filetypes=[
                    (
                        "Carrier and image files",
                        "*.bin *.jpg *.jpeg *.png *.gif *.bmp *.webp *.tif *.tiff",
                    ),
                    ("All files", "*"),
                ],
            )
        if selected:
            self.carrier_var.set(selected)
            self.last_carrier_dir = Path(selected).expanduser().parent
            self._update_paths()

    @staticmethod
    def _selection_directory(raw: str, fallback: Path) -> Path:
        """Choose a useful starting folder for the next desktop picker."""

        if not raw.strip():
            return fallback.expanduser()
        candidate = Path(raw).expanduser()
        return candidate if candidate.is_dir() else candidate.parent

    def _source_parent_directory(self) -> Path:
        raw = self.source_var.get().strip()
        if not raw:
            return self.last_source_dir
        return Path(raw).expanduser().parent

    def _source_changed(self) -> None:
        self._update_paths()
        if self.action_var.get() == "encrypt":
            self._start_estimate()

    def _update_paths(self) -> None:
        raw = self.source_var.get().strip()
        if not raw:
            self.output_var.set("Choose a file or folder")
            self.carrier_resolved_var.set(
                "Default: boop-key.bin beside the encrypted package"
            )
            if self.action_var.get() == "encrypt":
                self.estimate_var.set("Estimated compressed size: choose a source")
                self.encrypted_estimate_var.set(
                    "Estimated encrypted package: choose a source"
                )
            return
        source = Path(raw).expanduser()
        if self.action_var.get() == "encrypt":
            output = source.with_name(source.name + ".boopcrypt")
            self.output_var.set(os.fspath(output))
            if self.carrier_mode_var.get() == "create_bin":
                carrier_raw = self.carrier_var.get().strip()
                carrier = (
                    Path(carrier_raw).expanduser()
                    if carrier_raw
                    else output.parent / "boop-key.bin"
                )
                self.carrier_resolved_var.set(
                    f"Binary carrier will be created or reused at: {carrier}"
                )
            else:
                self.carrier_resolved_var.set(
                    "Select the existing carrier/image that will receive or reuse the key record."
                )
        else:
            self.output_var.set(
                "Restored name and type will be read from the verified carrier."
            )
            self.carrier_resolved_var.set(
                "The carrier must be the one used when this package was encrypted."
            )

    def _compression_code(self) -> str:
        if not self.compression_enabled_var.get():
            return "none"
        return COMPRESSIONS[self.compression_var.get()]

    def _start_estimate(self) -> None:
        if self.busy or self.action_var.get() != "encrypt":
            return
        raw = self.source_var.get().strip()
        if not raw:
            return
        source = Path(raw).expanduser()
        method = self._compression_code()
        self.estimate_generation += 1
        generation = self.estimate_generation
        self.estimate_var.set("Estimated compressed size: calculating...")
        self.encrypted_estimate_var.set(
            "Estimated encrypted package: calculating..."
        )

        def task() -> None:
            try:
                result = estimate_final_size(source, method)
                self.ui_queue.submit(
                    self._show_estimate_if_current,
                    generation,
                    result,
                )
            except Exception as exc:
                message = str(exc)
                self.ui_queue.submit(
                    self._show_estimate_error_if_current,
                    generation,
                    message,
                )

        threading.Thread(target=task, daemon=True).start()

    def _show_estimate_if_current(self, generation: int, result) -> None:
        if generation == self.estimate_generation:
            self._show_estimate(result)

    def _show_estimate_error_if_current(
        self,
        generation: int,
        message: str,
    ) -> None:
        if generation == self.estimate_generation:
            self._show_estimate_error(message)

    def _show_estimate(self, result) -> None:
        self.estimate_var.set(
            f"Estimated after compression: ~{human_size(result.compressed_bytes)} "
            f"({result.ratio * 100:.0f}% sample ratio)"
        )
        self.encrypted_estimate_var.set(
            f"Estimated encrypted package: ~{human_size(result.encrypted_bytes)}"
        )

    def _show_estimate_error(self, message: str) -> None:
        self.estimate_var.set(f"Estimate unavailable: {message}")
        self.encrypted_estimate_var.set(
            "Install the selected compression dependency if required."
        )

    def _queue_log(self, level: str, message: str, verbose: bool = False) -> None:
        self.log_queue.put((level, message, verbose))

    def _drain_queues(self) -> None:
        try:
            while True:
                level, message, _verbose = self.log_queue.get_nowait()
                stamp = dt.datetime.now().strftime("%H:%M:%S")
                self.console.configure(state=tk.NORMAL)
                self.console.insert(
                    tk.END,
                    f"{stamp} [{level}] {message}\n",
                    level if level in ("INFO", "SUCCESS", "WARN", "ERROR", "VERBOSE") else "INFO",
                )
                self.console.see(tk.END)
                self.console.configure(state=tk.DISABLED)
        except queue.Empty:
            pass
        try:
            self.ui_queue.drain()
        except Exception as exc:
            self._queue_log(
                "ERROR",
                f"Could not apply a completed background result: {exc}",
                False,
            )
        self.after(100, self._drain_queues)

    def _clear_console(self) -> None:
        self.console.configure(state=tk.NORMAL)
        self.console.delete("1.0", tk.END)
        self.console.configure(state=tk.DISABLED)

    def _set_busy(self, busy: bool, status: str = "Ready") -> None:
        self.busy = busy
        self.status_var.set(status)
        state = tk.DISABLED if busy else tk.NORMAL
        self.start_button.configure(state=state)
        self.test_button.configure(state=state)
        self.install_button.configure(state=state)
        self.estimate_button.configure(
            state=(
                tk.NORMAL
                if not busy and self.action_var.get() == "encrypt"
                else tk.DISABLED
            )
        )
        if busy:
            self.side_status_dot.configure(fg=COLORS["warning"])
            self.progress.start(10)
        else:
            self.progress.stop()
            colour = COLORS["danger"] if "failed" in status.lower() else COLORS["success"]
            self.side_status_dot.configure(fg=colour)
            self._update_mode()

    def _test_dependencies(self) -> None:
        if self.busy:
            return
        self._show_page("dependencies")
        self._queue_log("INFO", "Testing host dependencies...", False)
        status = check_dependencies()
        missing = []
        for command in DEPENDENCY_COMMANDS:
            path = status[command]
            if path:
                self._queue_log("SUCCESS", f"{command}: found at {path}", False)
                self.dependency_status_labels[command].configure(
                    text="Ready",
                    fg=COLORS["success"],
                )
            else:
                missing.append(command)
                self._queue_log("WARN", f"{command}: not installed", False)
                self.dependency_status_labels[command].configure(
                    text="Missing",
                    fg=COLORS["warning"],
                )
        if missing:
            self._queue_log(
                "WARN",
                "Missing optional/required commands: " + ", ".join(missing),
                False,
            )
            self.status_var.set("Dependencies missing")
            self.side_status_dot.configure(fg=COLORS["warning"])
            self.dependency_summary.configure(
                text="Missing: " + ", ".join(missing),
                fg=COLORS["warning"],
            )
        else:
            self._queue_log("SUCCESS", "All dependencies are installed.", False)
            self.status_var.set("Dependencies ready")
            self.side_status_dot.configure(fg=COLORS["success"])
            self.dependency_summary.configure(
                text="All five host tools are installed and ready.",
                fg=COLORS["success"],
            )

    def _install_dependencies(self) -> None:
        if self.busy:
            return
        try:
            commands, distro = dependency_install_commands()
        except DependencyError as exc:
            self._queue_log("ERROR", str(exc), False)
            messagebox.showerror("Cannot Install Dependencies", str(exc), parent=self)
            return
        self._queue_log(
            "INFO",
            f"Detected {distro}. Administrator authentication will be requested.",
            False,
        )
        self._set_busy(True, "Installing dependencies")
        self._show_page("activity")

        def task() -> None:
            try:
                for command in commands:
                    self._queue_log(
                        "INFO",
                        "Running: " + " ".join(command),
                        False,
                    )
                    process = subprocess.Popen(
                        command,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        bufsize=1,
                    )
                    assert process.stdout is not None
                    for line in process.stdout:
                        self._queue_log("INFO", line.rstrip(), False)
                    if process.wait() != 0:
                        raise DependencyError(
                            f"Dependency installation exited with status {process.returncode}."
                        )
                missing = [
                    name
                    for name, path in check_dependencies().items()
                    if path is None
                ]
                if missing:
                    raise DependencyError(
                        "Dependencies are still missing: " + ", ".join(missing)
                    )
                self._queue_log(
                    "SUCCESS",
                    "All dependencies were installed successfully.",
                    False,
                )
                self.ui_queue.submit(
                    self._finish_dependency_install,
                )
            except Exception as exc:
                message = str(exc)
                self._queue_log("ERROR", message, False)
                self.ui_queue.submit(
                    self._finish_worker,
                    "Dependency installation failed",
                    error=message,
                )

        self.worker = threading.Thread(target=task, daemon=True)
        self.worker.start()

    def _finish_dependency_install(self) -> None:
        for label in self.dependency_status_labels.values():
            label.configure(text="Ready", fg=COLORS["success"])
        self.dependency_summary.configure(
            text="All five host tools are installed and ready.",
            fg=COLORS["success"],
        )
        self._finish_worker("Dependencies ready")

    def _build_options(self) -> OperationOptions:
        raw_source = self.source_var.get().strip()
        if not raw_source:
            raise BoopCryptError("Choose the file or folder first.")
        carrier_raw = self.carrier_var.get().strip()
        action = self.action_var.get()
        carrier_mode = (
            "existing" if action == "decrypt" else self.carrier_mode_var.get()
        )
        if carrier_mode == "existing" and not carrier_raw:
            raise BoopCryptError("Choose the existing carrier file.")
        return OperationOptions(
            source=Path(raw_source).expanduser(),
            carrier=Path(carrier_raw).expanduser() if carrier_raw else None,
            carrier_mode=carrier_mode,
            cipher=CIPHERS[self.cipher_var.get()],
            compression=self._compression_code(),
            password=self.password_var.get(),
            remove_source=self.remove_source_var.get(),
        )

    def _start_operation(self) -> None:
        if self.busy:
            return
        try:
            options = self._build_options()
        except BoopCryptError as exc:
            messagebox.showerror("Check the Settings", str(exc), parent=self)
            return
        action = self.action_var.get()
        if options.remove_source:
            message = (
                "The original source will be removed only after the encrypted "
                "package and carrier pass end-to-end verification.\n\nContinue?"
                if action == "encrypt"
                else
                "The encrypted package will be removed only after the payload "
                "is restored and verified.\n\nContinue?"
            )
            if not messagebox.askyesno(
                f"Start {action.title()}ion",
                message,
                parent=self,
            ):
                return

        self._queue_log(
            "INFO",
            f"Starting {action} operation.",
            False,
        )
        self._set_busy(
            True,
            "Encrypting and verifying" if action == "encrypt" else "Decrypting and verifying",
        )
        self._show_page("activity")
        verbose = self.verbose_var.get()

        def task() -> None:
            engine = BoopCryptEngine(
                self._queue_log,
                verbose=verbose,
            )
            try:
                result = (
                    engine.encrypt(options)
                    if action == "encrypt"
                    else engine.decrypt(options)
                )
                self.ui_queue.submit(
                    self._operation_finished,
                    action,
                    result,
                )
            except Exception as exc:
                message = str(exc)
                self._queue_log("ERROR", message, False)
                self.ui_queue.submit(
                    self._finish_worker,
                    f"{action.title()} failed",
                    error=message,
                )

        self.worker = threading.Thread(target=task, daemon=True)
        self.worker.start()

    def _operation_finished(
        self,
        action: str,
        result: tuple[Path, Path],
    ) -> None:
        output, carrier = result
        self.password_var.set("")
        self._set_busy(False, "Ready")
        self.source_var.set("")
        self.carrier_var.set(os.fspath(carrier))
        self._update_paths()
        messagebox.showinfo(
            f"{action.title()} Complete",
            f"Output:\n{output}\n\nCarrier:\n{carrier}",
            parent=self,
        )

    def _finish_worker(
        self,
        status: str,
        *,
        error: str | None = None,
    ) -> None:
        self.password_var.set("")
        self._set_busy(False, status)
        if error:
            messagebox.showerror("Boop Crypt", error, parent=self)

    def _how_to_encrypt(self) -> None:
        messagebox.showinfo(
            "How to Encrypt",
            "1. Select Encrypt.\n"
            "2. Choose the file or folder.\n"
            "3. Choose AES-256 or another encryption method.\n"
            "4. Enable compression and select XZ, Zstandard or Gzip, or turn it off.\n"
            "5. Choose an existing carrier/image, or create a separate .bin carrier.\n"
            "6. Optionally enter a carrier password.\n"
            "7. Review the estimated size and select Encrypt.\n\n"
            "The original is removed only after compression, encryption, "
            "decryption testing, checksum verification and carrier update succeed.",
            parent=self,
        )

    def _how_to_decrypt(self) -> None:
        messagebox.showinfo(
            "How to Decrypt",
            "1. Select Decrypt.\n"
            "2. Choose the .boopcrypt package.\n"
            "3. Choose the separate image or .bin carrier used for encryption.\n"
            "4. Enter the carrier password if one was set.\n"
            "5. Select Decrypt.\n\n"
            "Boop Crypt verifies the encrypted SHA-256 checksum, decrypts and "
            "decompresses into a temporary location, validates the TAR archive, "
            "and only then restores the original file or folder.",
            parent=self,
        )

    def _carrier_help(self) -> None:
        messagebox.showinfo(
            "Carrier and Passwords",
            "The carrier stores the separate random encryption key and a list "
            "of packages that use it. It can be an image, an existing file or "
            "a generated boop-key.bin.\n\n"
            "Keep the carrier separate from the encrypted package. Losing it "
            "makes the package unrecoverable.\n\n"
            "An optional password encrypts the key inside the carrier. The "
            "password is not stored as readable text and is never printed in "
            "the console. The password is separate from the random encryption key.",
            parent=self,
        )

    def _dependency_help(self) -> None:
        messagebox.showinfo(
            "Dependency Commands",
            "Arch / CachyOS:\n"
            "sudo pacman -S --needed gnupg tar xz gzip zstd\n\n"
            "Debian / Ubuntu:\n"
            "sudo apt install gnupg tar xz-utils gzip zstd\n\n"
            "Fedora / Nobara:\n"
            "sudo dnf install gnupg2 tar xz gzip zstd\n\n"
            "The Install Dependencies button detects the distribution and uses "
            "pkexec for graphical administrator authentication.",
            parent=self,
        )

    def _about(self) -> None:
        messagebox.showinfo(
            f"About {APP_NAME}",
            f"{APP_NAME} GUI {APP_VERSION}\n\n"
            "Copyright (c) 2026 Peter George Haworth\n"
            "Released under the MIT License.\n\n"
            "Default AES-256 with XZ packages use the Boop Crypt 1.0.0 "
            "compatible carrier pipeline.",
            parent=self,
        )

    def _close(self) -> None:
        if self.busy and not messagebox.askyesno(
            "Operation Running",
            "An operation is still running. Closing now may leave temporary "
            "files until the process exits. Close anyway?",
            parent=self,
        ):
            return
        self.destroy()


def run_gui() -> None:
    app = BoopCryptApp()
    app.mainloop()
