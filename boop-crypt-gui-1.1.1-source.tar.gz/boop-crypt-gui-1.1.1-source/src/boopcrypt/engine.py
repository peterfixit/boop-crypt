"""Encryption and decryption operations for Boop Crypt GUI."""

from __future__ import annotations

import base64
import binascii
import os
import secrets
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Callable, Sequence

from .core import (
    APP_VERSION,
    CIPHERS,
    COMPRESSIONS,
    PACKAGE_S2K_COUNT,
    PASSWORD_WRAP_S2K_COUNT,
    BoopCryptError,
    CarrierState,
    OperationOptions,
    append_carrier_record,
    build_record,
    carrier_has_record,
    compare_files,
    detect_carrier_type,
    ensure_dependencies,
    generate_bin_carrier,
    normalize_record,
    required_commands,
    safe_chmod,
    sha256_file,
    strip_carrier,
    utc_now,
    validate_archive,
)


LogCallback = Callable[[str, str, bool], None]


class CommandRunner:
    def __init__(self, logger: LogCallback | None = None, verbose: bool = False):
        self.logger = logger or (lambda _level, _message, _verbose: None)
        self.verbose_enabled = verbose

    def log(self, level: str, message: str, verbose: bool = False) -> None:
        if not verbose or self.verbose_enabled:
            self.logger(level, message, verbose)

    def run(
        self,
        command: Sequence[str],
        *,
        stdin: bytes | None = None,
        stdout_path: Path | None = None,
        env: dict[str, str] | None = None,
        description: str | None = None,
    ) -> subprocess.CompletedProcess[bytes]:
        shown = description or " ".join(command)
        self.log("VERBOSE", f"Running: {shown}", True)
        output_handle = None
        stdout = subprocess.PIPE
        try:
            if stdout_path is not None:
                output_handle = stdout_path.open("wb")
                stdout = output_handle
            result = subprocess.run(
                list(command),
                input=stdin,
                stdout=stdout,
                stderr=subprocess.PIPE,
                env=env,
                check=False,
            )
        finally:
            if output_handle is not None:
                output_handle.close()
        if result.returncode != 0:
            detail = result.stderr.decode("utf-8", errors="replace").strip()
            if not detail:
                detail = f"command exited with status {result.returncode}"
            raise BoopCryptError(f"{shown} failed: {detail}")
        if result.stderr and self.verbose_enabled:
            detail = result.stderr.decode("utf-8", errors="replace").strip()
            if detail:
                self.log("VERBOSE", detail, True)
        return result


class BoopCryptEngine:
    def __init__(
        self,
        logger: LogCallback | None = None,
        *,
        verbose: bool = False,
        package_s2k_count: int = PACKAGE_S2K_COUNT,
        password_s2k_count: int = PASSWORD_WRAP_S2K_COUNT,
    ):
        self.runner = CommandRunner(logger, verbose)
        self.package_s2k_count = package_s2k_count
        self.password_s2k_count = password_s2k_count

    def log(self, level: str, message: str, verbose: bool = False) -> None:
        self.runner.log(level, message, verbose)

    @staticmethod
    def default_encrypted_path(source: Path) -> Path:
        return source.with_name(source.name + ".boopcrypt")

    @staticmethod
    def default_carrier_path(encrypted_path: Path) -> Path:
        return encrypted_path.parent / "boop-key.bin"

    @staticmethod
    def _absolute(path: Path) -> Path:
        return Path(os.path.abspath(os.fspath(path)))

    @staticmethod
    def _validate_distinct(paths: Sequence[Path]) -> None:
        normalized = [os.path.abspath(os.fspath(path)) for path in paths]
        if len(normalized) != len(set(normalized)):
            raise BoopCryptError("The source, encrypted package and carrier must use separate paths.")

    @staticmethod
    def _carrier_outside_source(source: Path, carrier: Path) -> None:
        if not source.is_dir() or source.is_symlink():
            return
        source_real = os.path.realpath(source)
        carrier_real = os.path.realpath(carrier)
        if carrier_real == source_real or carrier_real.startswith(source_real.rstrip(os.sep) + os.sep):
            raise BoopCryptError("The carrier must be outside the folder being encrypted.")

    @staticmethod
    def _check_directory_mounts(source: Path) -> None:
        if not source.is_dir() or source.is_symlink():
            return
        resolved = os.path.realpath(source)
        prefix = resolved.rstrip(os.sep) + os.sep
        try:
            lines = Path("/proc/self/mountinfo").read_text(encoding="utf-8").splitlines()
        except OSError:
            return
        for line in lines:
            fields = line.split()
            if len(fields) < 5:
                continue
            mountpoint = fields[4].replace("\\040", " ")
            real_mount = os.path.realpath(mountpoint)
            if real_mount == resolved or real_mount.startswith(prefix):
                raise BoopCryptError(
                    f"The selected folder contains or is the mount point {mountpoint}. "
                    "Unmount it before encryption so it cannot be removed accidentally."
                )

    @staticmethod
    def _validate_source(source: Path) -> None:
        if not source.exists() and not source.is_symlink():
            raise BoopCryptError(f"The selected source does not exist: {source}")
        if "\n" in source.name or source.name in (".", ".."):
            raise BoopCryptError("The selected source name is not supported.")
        if source.name.endswith((".boopcrypt", ".boopcrypt.xz")):
            raise BoopCryptError("Choose Decrypt for a .boopcrypt package.")

    def _load_or_create_carrier(
        self,
        options: OperationOptions,
        encrypted_path: Path,
        work: Path,
    ) -> CarrierState:
        if options.carrier_mode == "existing":
            if options.carrier is None:
                raise BoopCryptError("Choose an existing carrier file.")
            carrier = self._absolute(options.carrier)
            if not carrier.is_file() or carrier.is_symlink():
                raise BoopCryptError(
                    "The selected carrier must be a regular file, not a folder or symbolic link."
                )
        elif options.carrier_mode == "create_bin":
            carrier = self._absolute(
                options.carrier or self.default_carrier_path(encrypted_path)
            )
            if carrier.exists():
                if carrier.is_symlink() or not carrier.is_file():
                    raise BoopCryptError("The .bin carrier path is not a regular file.")
                if not carrier_has_record(carrier):
                    raise BoopCryptError(
                        f"{carrier.name} already exists and is not a recorded Boop Crypt carrier. "
                        "Choose another path."
                    )
                self.log("INFO", f"Reusing existing recorded carrier: {carrier}")
        else:
            raise BoopCryptError("Unknown carrier selection mode.")

        carrier.parent.mkdir(parents=True, exist_ok=True)
        base_path = work / "carrier-base"
        if carrier.exists():
            self.log("INFO", f"Reading carrier: {carrier}")
            record = strip_carrier(carrier, base_path)
        else:
            self.log("INFO", f"Creating binary carrier: {carrier}")
            generate_bin_carrier(base_path)
            record = None

        carrier_type = detect_carrier_type(base_path)
        base_hash = sha256_file(base_path)
        if record is None:
            key = base64.b64encode(secrets.token_bytes(48)).decode("ascii")
            return CarrierState(
                path=carrier,
                base_path=base_path,
                carrier_type=carrier_type,
                base_sha256=base_hash,
                vault_id=secrets.token_hex(16),
                created_utc=utc_now(),
                key_mode="plain",
                key_value=key,
                packages=[],
                had_record=False,
            )

        normalized = normalize_record(record, carrier_type)
        if not secrets.compare_digest(base_hash, normalized["base_sha256"]):
            raise BoopCryptError(
                "Carrier base SHA-256 verification failed. The carrier was altered."
            )
        self.log(
            "INFO",
            f"Existing carrier verified; it tracks {len(normalized['packages'])} package(s).",
        )
        return CarrierState(
            path=carrier,
            base_path=base_path,
            carrier_type=carrier_type,
            base_sha256=base_hash,
            vault_id=normalized["vault_id"],
            created_utc=normalized["created_utc"],
            key_mode=normalized["key_mode"],
            key_value=normalized["key_value"],
            packages=normalized["packages"],
            had_record=True,
        )

    @staticmethod
    def _gpg_env(work: Path) -> dict[str, str]:
        home = work / "gnupg"
        home.mkdir(mode=0o700, exist_ok=True)
        safe_chmod(home, 0o700)
        env = os.environ.copy()
        env["GNUPGHOME"] = os.fspath(home)
        return env

    def _gpg_encrypt(
        self,
        source: Path,
        destination: Path,
        key: str,
        cipher: str,
        work: Path,
    ) -> None:
        command = [
            "gpg",
            "--batch", "--yes", "--quiet",
            "--no-secmem-warning", "--no-autostart", "--no-symkey-cache",
            "--pinentry-mode", "loopback",
            "--passphrase-fd", "0",
            "--symmetric",
            "--cipher-algo", cipher,
            "--compress-algo", "none",
            "--s2k-mode", "3",
            "--s2k-digest-algo", "SHA512",
            "--s2k-count", str(self.package_s2k_count),
            "--output", os.fspath(destination),
            "--", os.fspath(source),
        ]
        self.runner.run(
            command,
            stdin=(key + "\n").encode(),
            env=self._gpg_env(work),
            description=f"GnuPG {cipher} encryption",
        )

    def _gpg_decrypt(
        self,
        source: Path,
        destination: Path,
        key: str,
        work: Path,
    ) -> None:
        command = [
            "gpg",
            "--batch", "--yes", "--quiet",
            "--no-secmem-warning", "--no-autostart", "--no-symkey-cache",
            "--pinentry-mode", "loopback",
            "--passphrase-fd", "0",
            "--decrypt",
            "--output", os.fspath(destination),
            "--", os.fspath(source),
        ]
        self.runner.run(
            command,
            stdin=(key + "\n").encode(),
            env=self._gpg_env(work),
            description="GnuPG decryption",
        )

    def _wrap_key(self, key: str, password: str, work: Path) -> str:
        key_file = work / "key-to-wrap.txt"
        wrapped = work / "wrapped-key.gpg"
        key_file.write_text(key, encoding="utf-8")
        safe_chmod(key_file)
        command = [
            "gpg",
            "--batch", "--yes", "--quiet",
            "--no-secmem-warning", "--no-autostart", "--no-symkey-cache",
            "--pinentry-mode", "loopback",
            "--passphrase-fd", "0",
            "--symmetric",
            "--cipher-algo", "AES256",
            "--s2k-mode", "3",
            "--s2k-digest-algo", "SHA512",
            "--s2k-count", str(self.password_s2k_count),
            "--compress-algo", "none",
            "--output", os.fspath(wrapped),
            "--", os.fspath(key_file),
        ]
        self.runner.run(
            command,
            stdin=(password + "\n").encode(),
            env=self._gpg_env(work),
            description="carrier-key password protection",
        )
        key_file.unlink(missing_ok=True)
        return base64.b64encode(wrapped.read_bytes()).decode("ascii")

    def _unwrap_key(self, wrapped_b64: str, password: str, work: Path) -> str:
        wrapped = work / "wrapped-key-input.gpg"
        output = work / "unwrapped-key.txt"
        try:
            wrapped.write_bytes(base64.b64decode(wrapped_b64, validate=True))
        except (ValueError, binascii.Error) as exc:
            raise BoopCryptError("The carrier's wrapped key is damaged.") from exc
        command = [
            "gpg",
            "--batch", "--yes", "--quiet",
            "--no-secmem-warning", "--no-autostart", "--no-symkey-cache",
            "--pinentry-mode", "loopback",
            "--passphrase-fd", "0",
            "--decrypt",
            "--output", os.fspath(output),
            "--", os.fspath(wrapped),
        ]
        try:
            self.runner.run(
                command,
                stdin=(password + "\n").encode(),
                env=self._gpg_env(work),
                description="carrier-key password verification",
            )
        except BoopCryptError as exc:
            raise BoopCryptError("The carrier password is incorrect.") from exc
        key = output.read_text(encoding="utf-8")
        output.unlink(missing_ok=True)
        wrapped.unlink(missing_ok=True)
        if len(key) < 60:
            raise BoopCryptError(
                "The carrier key is invalid after password verification."
            )
        return key

    def _obtain_key(
        self,
        state: CarrierState,
        password: str,
        work: Path,
        *,
        encrypting: bool,
    ) -> str:
        if state.key_mode == "gpg-wrapped":
            if not password:
                raise BoopCryptError(
                    "This carrier is password-protected. Enter its carrier password."
                )
            self.log("INFO", "Unlocking the password-protected carrier key.")
            return self._unwrap_key(state.key_value, password, work)
        if state.key_mode != "plain":
            raise BoopCryptError(
                "The carrier key-protection method is unsupported."
            )
        key = state.key_value
        if encrypting and password:
            self.log("INFO", "Adding password protection to the reusable carrier key.")
            state.key_value = self._wrap_key(key, password, work)
            state.key_mode = "gpg-wrapped"
        elif encrypting:
            self.log(
                "INFO",
                "No carrier password was selected; the carrier key remains unprotected.",
            )
        return key

    def _create_tar(self, source: Path, archive: Path) -> None:
        self.log("INFO", f"Creating TAR archive from {source.name}.")
        command = [
            "tar", "--sparse",
            "-C", os.fspath(source.parent),
            "-cf", os.fspath(archive),
            "--", source.name,
        ]
        self.runner.run(command, description="TAR archive creation")
        validate_archive(archive, source.name)

    def _compress(self, archive: Path, output: Path, method: str) -> None:
        if method == "none":
            self.log("INFO", "Compression is disabled; encrypting the TAR archive directly.")
            shutil.copyfile(archive, output)
            return
        self.log("INFO", f"Compressing with {method.upper()}.")
        if method == "xz":
            command = [
                "xz", "--threads=0", "-9e", "--check=sha256",
                "--stdout", "--", os.fspath(archive),
            ]
        elif method == "gzip":
            command = ["gzip", "-9", "--stdout", "--", os.fspath(archive)]
        elif method == "zstd":
            command = [
                "zstd", "-10", "-T0", "-q", "--stdout", "--", os.fspath(archive),
            ]
        else:
            raise BoopCryptError(f"Unsupported compression method: {method}")
        self.runner.run(
            command,
            stdout_path=output,
            description=f"{method.upper()} compression",
        )

    def _test_compressed(self, path: Path, method: str) -> None:
        if method == "none":
            return
        if method == "xz":
            command = ["xz", "--test", "--", os.fspath(path)]
        elif method == "gzip":
            command = ["gzip", "--test", "--", os.fspath(path)]
        elif method == "zstd":
            command = ["zstd", "--test", "-q", "--", os.fspath(path)]
        else:
            raise BoopCryptError(f"Unsupported compression method: {method}")
        self.runner.run(command, description=f"{method.upper()} integrity test")

    def _decompress(self, source: Path, output: Path, method: str) -> None:
        if method == "none":
            shutil.copyfile(source, output)
            return
        if method == "xz":
            command = [
                "xz", "--decompress", "--stdout", "--", os.fspath(source),
            ]
        elif method == "gzip":
            command = [
                "gzip", "--decompress", "--stdout", "--", os.fspath(source),
            ]
        elif method == "zstd":
            command = [
                "zstd", "--decompress", "-q", "--stdout", "--", os.fspath(source),
            ]
        else:
            raise BoopCryptError(f"Unsupported compression method: {method}")
        self.runner.run(
            command,
            stdout_path=output,
            description=f"{method.upper()} decompression",
        )

    @staticmethod
    def _new_package(
        source: Path,
        encrypted: Path,
        encrypted_hash: str,
        payload_hash: str,
        archive_hash: str,
        compression: str,
        cipher: str,
    ) -> dict:
        compatible = compression == "xz" and cipher == "AES256"
        package = {
            "pipeline": "beta2" if compatible else "gui1",
            "original_name": source.name,
            "encrypted_name": encrypted.name,
            "encrypted_sha256": encrypted_hash,
            "compressed_archive_sha256": payload_hash,
            "archive_sha256": archive_hash,
            "compression": compression,
            "encryption": "gpg-symmetric",
            "cipher": cipher,
            "created_utc": utc_now(),
        }
        if compression == "xz":
            package.update(
                {"compression_preset": "9e", "compression_threads": "auto"}
            )
        elif compression == "gzip":
            package["compression_level"] = 9
        elif compression == "zstd":
            package.update(
                {"compression_level": 10, "compression_threads": "auto"}
            )
        return package

    @staticmethod
    def _stage_carrier(state: CarrierState, record: dict, work: Path) -> Path:
        updated = work / "carrier-updated"
        append_carrier_record(state.base_path, record, updated)
        if state.carrier_type == "image" and detect_carrier_type(updated) != "image":
            raise BoopCryptError(
                "The carrier image is no longer recognised after embedding the record."
            )
        fd, stage_name = tempfile.mkstemp(
            prefix=f".{state.path.name}.boop-stage.",
            dir=state.path.parent,
        )
        os.close(fd)
        stage = Path(stage_name)
        shutil.copyfile(updated, stage)
        safe_chmod(stage)
        return stage

    @staticmethod
    def _replace_carrier(stage: Path, carrier: Path) -> Path | None:
        backup = None
        if carrier.exists():
            fd, backup_name = tempfile.mkstemp(
                prefix=f".{carrier.name}.boop-backup.",
                dir=carrier.parent,
            )
            os.close(fd)
            backup = Path(backup_name)
            backup.unlink()
            os.replace(carrier, backup)
        try:
            os.replace(stage, carrier)
            safe_chmod(carrier)
        except Exception:
            if backup and backup.exists():
                os.replace(backup, carrier)
            raise
        return backup

    @staticmethod
    def _remove_path(path: Path) -> None:
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()

    def encrypt(self, options: OperationOptions) -> tuple[Path, Path]:
        source = self._absolute(options.source)
        self._validate_source(source)
        self._check_directory_mounts(source)
        if options.cipher not in CIPHERS.values():
            raise BoopCryptError("Choose a supported encryption method.")
        if options.compression not in ("none", *COMPRESSIONS.values()):
            raise BoopCryptError("Choose a supported compression method.")
        ensure_dependencies(required_commands(options.compression))

        encrypted = self.default_encrypted_path(source)
        if encrypted.exists() or encrypted.is_symlink():
            raise BoopCryptError(f"The encrypted output already exists: {encrypted}")
        work = Path(tempfile.mkdtemp(prefix=".boop-work.", dir=encrypted.parent))
        safe_chmod(work, 0o700)
        carrier_stage = None
        try:
            state = self._load_or_create_carrier(options, encrypted, work)
            self._validate_distinct((source, encrypted, state.path))
            self._carrier_outside_source(source, state.path)
            if any(
                item.get("encrypted_name") == encrypted.name
                for item in state.packages
            ):
                raise BoopCryptError(
                    "The selected carrier already tracks that encrypted package name."
                )
            key = self._obtain_key(
                state,
                options.password,
                work,
                encrypting=True,
            )

            archive = work / "payload.tar"
            compressed = work / "payload.compressed"
            verify_archive = work / "verify-archive.tar"
            encrypted_temp = work / encrypted.name
            decrypted_verify = work / "verify-decrypted"
            final_verify = work / "verify-final.tar"

            self._create_tar(source, archive)
            archive_hash = sha256_file(archive)
            self._compress(archive, compressed, options.compression)
            if not compressed.exists() or compressed.stat().st_size == 0:
                raise BoopCryptError("Compression did not produce an output file.")
            self._test_compressed(compressed, options.compression)
            self._decompress(compressed, verify_archive, options.compression)
            if not compare_files(archive, verify_archive):
                raise BoopCryptError("Compression verification failed.")
            payload_hash = sha256_file(compressed)

            self.log("INFO", f"Encrypting with GnuPG {options.cipher}.")
            self._gpg_encrypt(
                compressed,
                encrypted_temp,
                key,
                options.cipher,
                work,
            )
            if not encrypted_temp.exists() or encrypted_temp.stat().st_size == 0:
                raise BoopCryptError("GnuPG did not produce an encrypted package.")

            self.log(
                "INFO",
                "Performing end-to-end decryption and checksum verification.",
            )
            self._gpg_decrypt(
                encrypted_temp,
                decrypted_verify,
                key,
                work,
            )
            if not compare_files(compressed, decrypted_verify):
                raise BoopCryptError("Encryption verification failed.")
            self._test_compressed(decrypted_verify, options.compression)
            self._decompress(
                decrypted_verify,
                final_verify,
                options.compression,
            )
            if not compare_files(archive, final_verify):
                raise BoopCryptError("End-to-end archive verification failed.")

            encrypted_hash = sha256_file(encrypted_temp)
            package = self._new_package(
                source,
                encrypted,
                encrypted_hash,
                payload_hash,
                archive_hash,
                options.compression,
                options.cipher,
            )
            packages = [*state.packages, package]
            carrier_stage = self._stage_carrier(
                state,
                build_record(state, packages),
                work,
            )

            self.log("INFO", "All checks passed; committing the package and carrier.")
            os.replace(encrypted_temp, encrypted)
            safe_chmod(encrypted)
            try:
                carrier_backup = self._replace_carrier(carrier_stage, state.path)
                carrier_stage = None
            except Exception as exc:
                encrypted.unlink(missing_ok=True)
                raise BoopCryptError(
                    "The carrier could not be updated; the original source "
                    f"was retained: {exc}"
                ) from exc
            if carrier_backup:
                try:
                    carrier_backup.unlink()
                except OSError as exc:
                    self.log("WARN", f"Could not remove temporary carrier backup: {exc}")

            if options.remove_source:
                try:
                    self._remove_path(source)
                except OSError as exc:
                    self.log(
                        "WARN",
                        "Encryption succeeded, but the original source could "
                        f"not be removed: {exc}",
                    )
            self.log("SUCCESS", f"Encrypted package created: {encrypted}")
            self.log(
                "SUCCESS",
                f"Carrier updated: {state.path} ({len(packages)} tracked package(s))",
            )
            return encrypted, state.path
        finally:
            if carrier_stage:
                carrier_stage.unlink(missing_ok=True)
            shutil.rmtree(work, ignore_errors=True)

    def _load_carrier_for_decryption(
        self,
        carrier: Path,
        work: Path,
    ) -> CarrierState:
        if not carrier.is_file() or carrier.is_symlink():
            raise BoopCryptError("Choose a regular Boop Crypt carrier file.")
        base = work / "carrier-base"
        record = strip_carrier(carrier, base)
        if record is None:
            raise BoopCryptError(
                "The selected carrier does not contain a Boop Crypt record."
            )
        carrier_type = detect_carrier_type(base)
        normalized = normalize_record(record, carrier_type)
        base_hash = sha256_file(base)
        if not secrets.compare_digest(base_hash, normalized["base_sha256"]):
            raise BoopCryptError(
                "Carrier base SHA-256 verification failed. The carrier was altered."
            )
        return CarrierState(
            path=carrier,
            base_path=base,
            carrier_type=carrier_type,
            base_sha256=base_hash,
            vault_id=normalized["vault_id"],
            created_utc=normalized["created_utc"],
            key_mode=normalized["key_mode"],
            key_value=normalized["key_value"],
            packages=normalized["packages"],
            had_record=True,
        )

    @staticmethod
    def _find_package(
        packages: list[dict],
        encrypted: Path,
        actual_hash: str,
    ) -> dict:
        named = [
            item for item in packages
            if item.get("encrypted_name") == encrypted.name
        ]
        if len(named) == 1:
            return named[0]
        hashed = [
            item for item in packages
            if item.get("encrypted_sha256") == actual_hash
        ]
        if len(hashed) == 1:
            return hashed[0]
        if not named and not hashed:
            raise BoopCryptError(
                "The encrypted package is not tracked by the selected carrier."
            )
        raise BoopCryptError(
            "The selected carrier does not identify the encrypted package uniquely."
        )

    def _decrypt_package(
        self,
        package: dict,
        encrypted: Path,
        key: str,
        work: Path,
    ) -> tuple[Path, str]:
        pipeline = package.get("pipeline")
        original_name = package.get("original_name")
        if (
            not isinstance(original_name, str)
            or not original_name
            or original_name in (".", "..")
            or "/" in original_name
            or "\x00" in original_name
            or "\n" in original_name
        ):
            raise BoopCryptError(
                "The carrier contains an unsafe original filename."
            )

        archive = work / "decrypted.tar"
        if pipeline == "alpha1":
            self._gpg_decrypt(encrypted, archive, key, work)
            return archive, original_name
        if pipeline == "beta1":
            ciphertext = work / "legacy-ciphertext.boopcrypt"
            self._test_compressed(encrypted, "xz")
            self._decompress(encrypted, ciphertext, "xz")
            expected = package.get("ciphertext_sha256")
            if expected and not secrets.compare_digest(
                sha256_file(ciphertext),
                str(expected),
            ):
                raise BoopCryptError(
                    "Legacy ciphertext checksum verification failed."
                )
            self._gpg_decrypt(ciphertext, archive, key, work)
            return archive, original_name
        if pipeline not in ("beta2", "gui1"):
            raise BoopCryptError(f"Unsupported package pipeline: {pipeline}")

        compression = package.get(
            "compression",
            "xz" if pipeline == "beta2" else None,
        )
        if compression not in ("none", "xz", "gzip", "zstd"):
            raise BoopCryptError(
                f"Unsupported package compression method: {compression}"
            )
        ensure_dependencies(required_commands(str(compression)))
        compressed = work / "decrypted-compressed"
        self._gpg_decrypt(encrypted, compressed, key, work)
        expected_compressed = package.get("compressed_archive_sha256")
        if expected_compressed and not secrets.compare_digest(
            sha256_file(compressed),
            str(expected_compressed),
        ):
            raise BoopCryptError(
                "Decrypted compressed-archive checksum verification failed."
            )
        self._test_compressed(compressed, str(compression))
        self._decompress(compressed, archive, str(compression))
        expected_archive = package.get("archive_sha256")
        if expected_archive and not secrets.compare_digest(
            sha256_file(archive),
            str(expected_archive),
        ):
            raise BoopCryptError("Decompressed TAR checksum verification failed.")
        return archive, original_name

    def decrypt(self, options: OperationOptions) -> tuple[Path, Path]:
        encrypted = self._absolute(options.source)
        if not encrypted.is_file() or encrypted.is_symlink():
            raise BoopCryptError(
                "Choose a regular .boopcrypt package to decrypt."
            )
        if options.carrier is None:
            raise BoopCryptError(
                "Choose the separate carrier file used for this package."
            )
        carrier = self._absolute(options.carrier)
        self._validate_distinct((encrypted, carrier))
        ensure_dependencies(("gpg", "tar"))

        work = Path(tempfile.mkdtemp(prefix=".boop-work.", dir=encrypted.parent))
        safe_chmod(work, 0o700)
        carrier_stage = None
        encrypted_backup = None
        try:
            self.log("INFO", f"Reading and verifying carrier: {carrier}")
            state = self._load_carrier_for_decryption(carrier, work)
            actual_hash = sha256_file(encrypted)
            package = self._find_package(
                state.packages,
                encrypted,
                actual_hash,
            )
            expected_hash = package.get("encrypted_sha256")
            if (
                not isinstance(expected_hash, str)
                or not secrets.compare_digest(actual_hash, expected_hash)
            ):
                raise BoopCryptError(
                    "Encrypted-package SHA-256 verification failed."
                )
            key = self._obtain_key(
                state,
                options.password,
                work,
                encrypting=False,
            )
            self.log("INFO", f"Decrypting verified package: {encrypted.name}")
            archive, original_name = self._decrypt_package(
                package,
                encrypted,
                key,
                work,
            )
            validate_archive(archive, original_name)

            restored = encrypted.parent / original_name
            if restored.exists() or restored.is_symlink():
                raise BoopCryptError(
                    f"The restored path already exists: {restored}"
                )
            extraction = work / "extracted"
            extraction.mkdir(mode=0o700)
            self.runner.run(
                [
                    "tar", "-xf", os.fspath(archive),
                    "-C", os.fspath(extraction),
                    "--no-same-owner",
                ],
                description="verified TAR extraction",
            )
            extracted = extraction / original_name
            if not extracted.exists() and not extracted.is_symlink():
                raise BoopCryptError(
                    "The archive did not restore the expected file or folder."
                )

            packages = state.packages
            if options.remove_source:
                packages = [
                    item for item in state.packages if item is not package
                ]
                carrier_stage = self._stage_carrier(
                    state,
                    build_record(state, packages),
                    work,
                )

            self.log("INFO", "All checks passed; committing the restored payload.")
            os.replace(extracted, restored)
            if carrier_stage:
                encrypted_backup = work / "encrypted-package.backup"
                try:
                    os.replace(encrypted, encrypted_backup)
                    carrier_backup = self._replace_carrier(
                        carrier_stage,
                        state.path,
                    )
                    carrier_stage = None
                except Exception as exc:
                    if encrypted_backup.exists():
                        os.replace(encrypted_backup, encrypted)
                    if restored.exists() or restored.is_symlink():
                        os.replace(restored, extracted)
                    raise BoopCryptError(
                        "The carrier could not be updated; encrypted state "
                        f"was retained: {exc}"
                    ) from exc
                encrypted_backup.unlink(missing_ok=True)
                if carrier_backup:
                    try:
                        carrier_backup.unlink()
                    except OSError as exc:
                        self.log(
                            "WARN",
                            f"Could not remove temporary carrier backup: {exc}",
                        )

            self.log("SUCCESS", f"Restored payload: {restored}")
            if options.remove_source:
                self.log(
                    "SUCCESS",
                    "Encrypted package removed; carrier now tracks "
                    f"{len(packages)} package(s).",
                )
            else:
                self.log(
                    "INFO",
                    "The encrypted package and its carrier record were retained.",
                )
            return restored, state.path
        finally:
            if carrier_stage:
                carrier_stage.unlink(missing_ok=True)
            if encrypted_backup and encrypted_backup.exists():
                try:
                    os.replace(encrypted_backup, encrypted)
                except OSError:
                    pass
            shutil.rmtree(work, ignore_errors=True)
