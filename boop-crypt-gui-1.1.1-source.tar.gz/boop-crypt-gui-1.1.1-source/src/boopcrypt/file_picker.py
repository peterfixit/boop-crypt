"""Desktop-native file chooser with a safe Tk fallback."""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from tkinter import filedialog
from typing import Callable, Sequence
from urllib.parse import unquote, urlparse


FileType = tuple[str, str]
Runner = Callable[..., subprocess.CompletedProcess[str]]
Which = Callable[[str], str | None]


class DesktopFilePicker:
    """Use the user's full desktop chooser when one is installed.

    KDE's KDialog is preferred, followed by Zenity on GTK desktops.  Tk's
    built-in chooser remains available for small/minimal desktop installs.
    """

    def __init__(
        self,
        parent: object,
        *,
        runner: Runner = subprocess.run,
        which: Which = shutil.which,
    ) -> None:
        self.parent = parent
        self._runner = runner
        self._which = which

    @property
    def backend_name(self) -> str:
        if self._which("kdialog"):
            return "KDE native picker (KDialog)"
        if self._which("zenity"):
            return "GTK native picker (Zenity)"
        return "built-in picker"

    def open_file(
        self,
        *,
        title: str,
        filetypes: Sequence[FileType],
        initial_dir: Path,
    ) -> str:
        initial = os.fspath(initial_dir.expanduser())
        selected = self._try_native(
            kind="open",
            title=title,
            initial=initial,
            filetypes=filetypes,
        )
        if selected is not None:
            return selected
        return filedialog.askopenfilename(
            parent=self.parent,
            title=title,
            initialdir=initial,
            filetypes=list(filetypes),
        )

    def open_directory(self, *, title: str, initial_dir: Path) -> str:
        initial = os.fspath(initial_dir.expanduser())
        selected = self._try_native(
            kind="directory",
            title=title,
            initial=initial,
            filetypes=(),
        )
        if selected is not None:
            return selected
        return filedialog.askdirectory(
            parent=self.parent,
            title=title,
            initialdir=initial,
            mustexist=True,
        )

    def save_file(
        self,
        *,
        title: str,
        filetypes: Sequence[FileType],
        initial_dir: Path,
        initial_file: str,
        default_extension: str,
    ) -> str:
        initial_path = initial_dir.expanduser() / initial_file
        selected = self._try_native(
            kind="save",
            title=title,
            initial=os.fspath(initial_path),
            filetypes=filetypes,
        )
        if selected is not None:
            if selected and default_extension and not Path(selected).suffix:
                selected += default_extension
            return selected
        return filedialog.asksaveasfilename(
            parent=self.parent,
            title=title,
            initialdir=os.fspath(initial_dir.expanduser()),
            initialfile=initial_file,
            defaultextension=default_extension,
            filetypes=list(filetypes),
        )

    def _try_native(
        self,
        *,
        kind: str,
        title: str,
        initial: str,
        filetypes: Sequence[FileType],
    ) -> str | None:
        """Return a selection/cancellation, or None when Tk should take over."""

        for backend in ("kdialog", "zenity"):
            executable = self._which(backend)
            if not executable:
                continue
            command = (
                self._kdialog_command(executable, kind, title, initial, filetypes)
                if backend == "kdialog"
                else self._zenity_command(executable, kind, title, initial, filetypes)
            )
            try:
                completed = self._runner(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    check=False,
                )
            except OSError:
                continue

            output = self._normalize_output(completed.stdout)
            if completed.returncode == 0 and output:
                return output
            if completed.returncode == 1:
                # Both tools use status 1 for an ordinary Cancel action.
                return ""
            # A broken native backend should not strand the user. Try the next
            # native backend, then fall back to Tk if neither one can open.
        return None

    @staticmethod
    def _kdialog_command(
        executable: str,
        kind: str,
        title: str,
        initial: str,
        filetypes: Sequence[FileType],
    ) -> list[str]:
        option = {
            "open": "--getopenfilename",
            "directory": "--getexistingdirectory",
            "save": "--getsavefilename",
        }[kind]
        command = [executable, "--title", title, option, initial]
        if kind != "directory" and filetypes:
            command.append(
                "\n".join(f"{patterns}|{label}" for label, patterns in filetypes)
            )
        return command

    @staticmethod
    def _zenity_command(
        executable: str,
        kind: str,
        title: str,
        initial: str,
        filetypes: Sequence[FileType],
    ) -> list[str]:
        filename = initial
        if kind == "directory" and not filename.endswith(os.sep):
            filename += os.sep
        command = [
            executable,
            "--file-selection",
            f"--title={title}",
            f"--filename={filename}",
        ]
        if kind == "directory":
            command.append("--directory")
        elif kind == "save":
            command.extend(("--save", "--confirm-overwrite"))
        for label, patterns in filetypes:
            command.append(f"--file-filter={label} | {patterns}")
        return command

    @staticmethod
    def _normalize_output(raw: str) -> str:
        selected = raw.rstrip("\r\n")
        parsed = urlparse(selected)
        if parsed.scheme == "file":
            return unquote(parsed.path)
        return selected
